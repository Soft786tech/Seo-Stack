<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="{{ asset('public/css/style.css') }}" rel="stylesheet" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">

    <title>seo-stack.io</title>
</head>
<style>
    body {
        font-family: 'Quicksand', sans-serif;
    }

</style>

<body>
    <nav class="navbar navbar-expand-lg cust-nav">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">sample page</a>
                </li>
                <li class="nav-item nav-right">
                    <a class="nav-link" href="{{ url('/login') }}">Login</a>
                </li>
            </ul>

        </div>

        <ul class="right-nav">
            <li class="nav-item">
                <a class="nav-link" href="{{ url('/login') }}">Login</a>
            </li>
        </ul>

    </nav>


    <section class="home-banner">

        <div class="container">
            <div class="row">
                <div class="col-md-6 banner-left-section">
                    <div class="banner-text">
                        <h1>SEO-STACK</h1>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                            been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a
                            galley of type and scrambled it to make a type specimen book.</p>
                    </div>
                    <div class="banner-btn">
                        <a href="#">Click Here</a>
                    </div>
                </div>
                <div class="col-md-6"></div>
            </div>
        </div>
    </section>

    <section class="cust-section">
        <div class="container">
            <div class="cust-flex">
                <div>
                    <div class="img-wrapper">
                        <img style="width: 100%" src="{{ asset('public/images/seo-slides-2.png') }}">
                    </div>
                </div>
                <div>
                    <div class="wrapper-text">
                        <h1>More Than Just an SEO Stack</h1>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a
                            page when looking at its layout. The point of using Lorem Ipsum is that it has a
                            more-or-less normal distribution of letters, as opposed to using ‘Content here, content
                            here’, making it look like readable English. Many desktop publishing packages and web page
                            editors now use Lorem Ipsum as their default model text.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class=" cust-section-bg">
        <div class="container">
            <div class="cust-flex">
                <div class="col-top-pad">
                    <div class="wrapper-text-1">
                        <h1>More Than Just an SEO Stack</h1>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a
                            page when looking at its layout. The point of using Lorem Ipsum is that it has a
                            more-or-less normal distribution of letters, as opposed to using ‘Content here, content
                            here’, making it look like readable English. Many desktop publishing packages and web page
                            editors now use Lorem Ipsum as their default model text.</p>
                    </div>

                </div>
                <div>
                    <div class="img-wrapper">
                        <img style="width: 100%" src="{{ asset('public/images/vector-image-13.png') }}">
                    </div>
                </div>
            </div>

        </div>
        <div class="cust-svg"></div>
    </section>


    <section class="cust-section">
        <div class="container">

            <div class="row cust-projects">
                <div class="col-md-12 ">
                    <h1>Our Projects</h1>
                    <p>It is a long established fact that a reader will be distracted by the readable content of a page
                        when looking at its layout.</p>
                </div>
            </div>

            <div class="cust-flex">
                <div>
                    <div class="icon-wrapper">
                        <i class="fas fa-tv"></i>
                    </div>
                    <div class="et_pb_blurb_container">
                        <h4 class="et_pb_module_header">
                            <span>Your Title Goes Here</span>
                        </h4>
                        <div class="et_pb_blurb_description">
                            <p>Your content goes here. Edit or remove this text inline or in the module Content
                                settings. You can also style every aspect of this content in the module Design settings
                                and even apply custom CSS to this text in the module Advanced settings.</p>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="icon-wrapper">
                        <i class="fas fa-camera"></i>
                    </div>
                    <div class="et_pb_blurb_container">
                        <h4 class="et_pb_module_header">
                            <span>Your Title Goes Here</span>
                        </h4>
                        <div class="et_pb_blurb_description">
                            <p>Your content goes here. Edit or remove this text inline or in the module Content
                                settings. You can also style every aspect of this content in the module Design settings
                                and even apply custom CSS to this text in the module Advanced settings.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <footer class="cust-footer">

        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h1>seo-stack</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley
                        of type and scrambled it to make a type specimen book.</p>
                </div>
                <div class="col-md-4">
                    <h1>useful links</h1>
                    <ul class="cust-ul">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Sample Page</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h1>social links</h1>
                    <ul class="social-links">
                        <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>

                    </ul>
                </div>
            </div>
        </div>




    </footer>












    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


</body>

</html>
