<template>
	<div class="card-body query-card-table-warpper query-card-table" v-if="!isDetails">
		<div class="p-0">
			<input type="hidden" v-model="keywords" id="search-keywords" />
			<table class="table" id="keywords-tables">
				<thead>
					<tr>
						<th>URL</th>
						<th class="sorting order-by" v-bind:class="((orderBy == 'clicks' && orderState == 'desc') ? 'sorting_desc' : 'sorting_asc')" orderType="clicks">Volume of Queries</th>
						<!-- <th class="sorting order-by" v-bind:class="((orderBy == 'impressions' && orderState == 'desc') ? 'sorting_desc' : 'sorting_asc')" orderType="impressions">Impressions</th> -->
						<th class="sorting order-by" v-bind:class="((orderBy == 'ctr' && orderState == 'desc') ? 'sorting_desc' : 'sorting_asc')" orderType="ctr">Volume of Queries with Clicks</th>
						<th class="sorting order-by" v-bind:class="((orderBy == 'pos' && orderState == 'desc') ? 'sorting_desc' : 'sorting_asc')" orderType="pos">Volume of Queries</th>
					</tr>
				</thead>
				<tbody>
					<tr v-for="keywordDetails in keywordDetails.data" :key="keywordDetails.data">
						<td><a href="javascript:void(0)" @click="getKeywordDetails(keywordDetails)">{{keywordDetails.sites}}</a></td>
						<td>{{keywordDetails.totalQ}}</td>
						<td>{{keywordDetails.tClicks}}</td>
						<td>{{keywordDetails.tClicks}}</td>
						<!-- <td>{{(Math.round(keywordDetails.tImpression * 100) / 100).toFixed(2)}}</td> -->
						<!-- <td>{{(Math.round(keywordDetails.tPosision * 100) / 100).toFixed(2)}}</td> -->
					</tr>
				</tbody>
			</table>
		</div>



	
<div class="row">



<div class="col-sm-6">
<div class="per">
<div>Rows per page</div>
<div>
<select class="form-control choose" id="total" name="total"> 
		        <option val="10" selected>10</option>
		        <option val="15">15</option>
				<option val="20">20</option>
				<option val="25">25</option>
				<option val="30">30</option>
	         </select>
</div>
<div class="query">
<b id="idd" class="work">{{pass}}</b> of {{rel}}
	</div>	
</div>	
</div>







<div class="col-sm-6">	
		  <div class="card-header">
			<div class="card-tools table-pagination" v-html="pagination"></div>	
		  </div>
</div> 



</div>
		   

  


	</div>
	<div class="query-card-table" v-if="isDetails">
		<a href="javascript:void(0)" @click="backToListing()" class="btn btn-primary">Back to Listing</a>
		<table class="table" id="keywords-details-tables">
			<thead>
				<tr>
					<th>Page</th>
					<th>Clicks</th>
					<th>Impressions</th>
					<th>CTR </th>
					<th>AVG Pos</th>
					<th>keywords</th>
				</tr>
			</thead>
			<tbody v-html="keywordSitesDetails"></tbody>
		</table>
	</div>
	<div class="card alert alert-danger alert-dismissible" v-if="!user">
		<strong>Please login to access this page!</strong>
	</div>	
</template>

<script>
import { Inertia } from "@inertiajs/inertia";
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";
import Dashboard from "./Reports";

export default {
    components: {
        Link
    },
    name: "QueryReport",
	methods: {
		getKeywordDetails: function(keywordDetail=""){
			var tableHtml = '';
			if(typeof keywordDetail.sites !== undefined){
				var completeDetails = new Array();
				for(const [key, value] of Object.entries(keywordDetail.completeDetails)){
					completeDetails[key] = {
						date: value.date,
						clicks: value.clicks,
						impressions: value.impressions,
						ctr: value.ctr,
						position: value.position
					};
				}
				
				Dashboard.methods.getSiteKeywordsRelatedDataFunc(completeDetails, this.$parent);
				
				for(const [key, value] of Object.entries(keywordDetail.sites)){
					tableHtml += '<tr>';
						tableHtml += '<td>'+value.site+'</td>';
						tableHtml += '<td>'+value.clicks+'</td>';
						tableHtml += '<td>'+value.impressions+'</td>';
						tableHtml += '<td>'+Number(value.ctr).toFixed(2)+'</td>';
						tableHtml += '<td>'+Number(value.position).toFixed(2)+'</td>';
						tableHtml += '<td>'+value.keywords+'</td>';
					tableHtml += '</tr>';
				}
			}
			else{
				tableHtml += '<tr>';
					tableHtml += '<td colspan="6" align="center"><strong>No Records Founds!</strong></td>';
				tableHtml += '</tr>';
			}
			
			this.isDetails = true;
			this.keywordSitesDetails = tableHtml;	
		},
		backToListing: function(){
			this.isDetails = false;
			Dashboard.methods.getDefaultSiteKeywordsRelatedDataFunc(this.$parent);
		}
	},	
	created () {
    },		
	mounted () {
		const vueObj = this;
		var orderBy = "clicks";
		var order = "asc";
		var currentLocation = window.location.href;			
		var baseURL = jQuery("#baseURL").val();
		const keywordDetails = usePage().props.value.keywordDetails;
		
		const getData = usePage().props.value.getData;
		
		jQuery(document).on("click", ".get-keyword-details", function(){
			var tableHtml = '';
			var keywordDetail = jQuery(this).attr("keywordDetails");
			keywordDetail = JSON.parse(keywordDetail);
			vueObj.getKeywordDetails(keywordDetail);
		});







		$(document).on("change", "select.choose", function(){
            var y          = jQuery("#total").val();
			
			var siteURL = jQuery("#selectedSite option:selected").text();
			var checkNum = currentLocation.split("/");
			var checkNumStatus = parseInt(checkNum[checkNum.length-1]);
			var pageNumber = 1;
			jQuery("#ajax-loading").css("display", "flex");
			jQuery(".pagination li.page-item").removeClass("active");
			jQuery(this).closest("li.page-item").addClass("active");
			
			if(!Number.isInteger(checkNumStatus)){
				checkNum.splice(-1);
				currentLocation = checkNum.join("/");
			}
			
			var data = {
				to:y,
				siteURL: siteURL,
				page: pageNumber,
				orderBy: orderBy,
				order: order,
				keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
				queryFilter: ((typeof getData['queryFilter'] !== "undefined") ? getData['queryFilter'] : ""),			
				url: ((typeof getData['url'] !== "url") ? getData['url'] : ""),
				pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),
				country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),				
				startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
				endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),				
				filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),
				_token: usePage().props.value.csrf_token,
			};

			jQuery.get(baseURL+"/query-table/1", data, function(response){
			   
				addingQueryTableHtmlFunc(response);
				jQuery("#ajax-loading").hide();
			});	
			
			return false;
        
        });







			
		
		jQuery(document).on('click', ".page-link", function (){
			var t     = jQuery("#total").val();
			var pageNumber = jQuery(this).attr('pageNumber');
			var siteURL = jQuery("#selectedSite option:selected").text();
			
			


			var checkNum = currentLocation.split("/");
			var checkNumStatus = parseInt(checkNum[checkNum.length-1]);
			
			jQuery("#ajax-loading").css("display", "flex");
			jQuery(".pagination li.page-item").removeClass("active");
			jQuery(this).closest("li.page-item").addClass("active");
			
			if(!Number.isInteger(checkNumStatus)){
				checkNum.splice(-1);
				currentLocation = checkNum.join("/");
			}
			
			var data = {
				to:t,
				siteURL: siteURL,
				page: pageNumber,
				orderBy: orderBy,
				order: order,
				keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
				queryFilter: ((typeof getData['queryFilter'] !== "undefined") ? getData['queryFilter'] : ""),			
				url: ((typeof getData['url'] !== "url") ? getData['url'] : ""),
				pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),
				country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),				
				startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
				endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),				
				filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),
				_token: usePage().props.value.csrf_token,
			};
            
			jQuery.get(baseURL+"/report/query-table/"+pageNumber, data, function(response){
				addingQueryTableHtmlFunc(response);
				jQuery("#ajax-loading").hide();
			});	
			
			return false;
		});			
		
		jQuery(".order-by").on("click", function(){
			var z          = jQuery("#total").val();
			var curElm = jQuery(this);
			jQuery("#ajax-loading").css("display", "flex");
			var checkNum = currentLocation.split("/");
			var checkNumStatus = parseInt(checkNum[checkNum.length-1]);			
			var siteURL = jQuery("#selectedSite option:selected").text();
			orderBy = jQuery(curElm).attr("orderType");
			order = (jQuery(curElm).hasClass("sorting_asc")) ? "desc" : "asc";
			if(Number.isInteger(checkNumStatus)){
				checkNum.splice(-1);
				currentLocation = checkNum.join("/");
			}
			
			var data = {
			    to:z,
				siteURL: siteURL,
				orderBy: orderBy,
				keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
				queryFilter: ((typeof getData['queryFilter'] !== "undefined") ? getData['queryFilter'] : ""),			
				url: ((typeof getData['url'] !== "url") ? getData['url'] : ""),
				pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),
				country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),				
				startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
				endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),				
				filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),
				order: order,
				page: 1,
				_token: usePage().props.value.csrf_token,
			};			
			
			jQuery.get(baseURL+"/query-table/1", data, function(response){
				addingQueryTableHtmlFunc(response);
				if(jQuery(curElm).hasClass("sorting_asc")){
					jQuery(curElm).removeClass("sorting_asc");
					jQuery(curElm).addClass("sorting_desc");
				}
				else{
					jQuery(curElm).addClass("sorting_asc");				
					jQuery(curElm).removeClass("sorting_desc");
				}
				jQuery("#ajax-loading").hide();
			});
			return false;
		});		
		
		function addingQueryTableHtmlFunc(response){
			response = JSON.parse(response);
			response = response.data;
			console.log(response);
									
			if(
				typeof response.pagination !== undefined &&
				typeof response.keywordDetails !== undefined
			){
				var tableHtml = '';
				
				for(const [key, value] of Object.entries(response)){							
					var totalCtr = Number(value.tPosision);
					var totalPosition = Number(value.tPosision);
					
					tableHtml += '<tr>';
						tableHtml += '<td><a href="javascript:void(0)" keywordDetails=\''+JSON.stringify(value)+'\' class="get-keyword-details" >'+value.sites+'</a></td>';
						tableHtml += '<td>'+value.totalQ+'</td>';
						tableHtml += '<td>'+value.tClicks+'</td>';
						tableHtml += '<td>'+((typeof totalCtr !== undefined) ? totalCtr.toFixed(2) : 0)+'</td>';
						tableHtml += '<td>'+((typeof totalPosition !== undefined) ? totalPosition.toFixed(2) : 0)+'</td>';
					tableHtml += '</tr>';
				}
				jQuery('#idd').html(response.per);
				jQuery("#keywords-tables tbody").html(tableHtml);
				jQuery(".table-pagination").html(response.pagination);
			}
		}		
    },	
	data() {
		return {
			isDetails: false,
			keywordSitesDetails: "",
			updateKeywordsHtml: "",
			pagination: "",
			pageID:'hello',
			
		}
	},	
    setup(props) {
		
		const user = computed(() => usePage().props.value.auth.user);
		const keywordDetails = computed(() => usePage().props.value.keywordDetails);
		const pagination = computed(() => usePage().props.value.pagination);
		const rel = computed(() => usePage().props.value.rel);
		const pass = computed(() => usePage().props.value.pass);
		// const keywordDetails = usePage().props.value.keywordDetails;
		// const pagination = usePage().props.value.pagination;
		// const rel = usePage().props.value.rel;
		// const pass = usePage().props.value.pass;
	    
				
        return {
            user,
			keywordDetails,
			pagination,
			rel,
			pass,
		
			
			
        }		
	}
}
</script>
<style scoped>
.query-card-table-warpper{
	margin-top: 20px;
}
table > thead > tr > th:not(.sorting_disabled), 
table > thead > tr > td:not(.sorting_disabled){
	padding-right: 30px;
	cursor: pointer;
	position: relative;  
}
table > thead .sorting::after, 
table > thead .sorting_asc::after, 
table > thead .sorting_desc::after, 
table.dataTable > thead .sorting_asc_disabled::after, 
table > thead .sorting_desc_disabled::after{
	right: .5em;
	content: "↓";
}
table > thead .sorting::before, 
table > thead .sorting_asc::before, 
table > thead .sorting_desc::before, 
table > thead .sorting_asc_disabled::before, 
table > thead .sorting_desc_disabled::before {
	right: 1em;
	content: "↑";
	position: absolute;
	bottom: .9em;
	display: block;  
}
table > thead .sorting::before, 
table > thead .sorting::after, 
table > thead .sorting_asc::before, 
table > thead .sorting_asc::after, 
table > thead .sorting_desc::before, 
table > thead .sorting_desc::after, 
table > thead .sorting_asc_disabled::before, 
table.dataTable > thead .sorting_asc_disabled::after, 
table.dataTable > thead .sorting_desc_disabled::before, 
table > thead .sorting_desc_disabled::after{
	position: absolute;
	bottom: .9em;
	display: block;
	opacity: .3;
}
table > thead .sorting_asc::before, 
table > thead .sorting_desc::after{
	opacity: 1;
}
table > thead .sorting, 
table.dataTable > thead .sorting_asc, 
table > thead .sorting_desc, 
table.dataTable > thead .sorting_asc_disabled, 
table > thead .sorting_desc_disabled{
	cursor: pointer;
}
[orderType="clicks"]::before{
	right:70px !important;
}
[orderType="clicks"]::after{
	right:60px !important;
}
[orderType="impressions"]::before{
	right:98px !important;
}
[orderType="impressions"]::after{
	right:88px !important;
}
[orderType="ctr"]::before{
	right:62px !important;
}
[orderType="ctr"]::after{
	right:52px !important;
}
[orderType="pos"]::before{
	right:72px !important;
}
[orderType="pos"]::after{
	right:62px !important;
}

.drop{
	margin-top:15px;

}
.choose{
	width: 63px;
	border: none;
	background:#f4f6f9 ;

}



.per{
	padding-left: 20px;
	margin-top: 19px;
	display: flex;
	align-items: center;
	width: 350px;
	height: 50px;
	/* background:#f4f6f9 ; */
	background-color: rgba(0,0,0,.03);
}

.query{
	padding-left: 15px;
}

.work{
	font-weight: normal;
}




</style>