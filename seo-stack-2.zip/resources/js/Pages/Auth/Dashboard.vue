<template>
	<div class="wrapper testClass">
		<app-header></app-header>
		<app-sidebar></app-sidebar>
		<div class="content-wrapper">
			<div class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
							<h1 class="m-0">Dashboard</h1>
						</div>
					</div>
				</div>
			</div>
			<div class="content">
				<div class="container-fluid">
					<div class="row">			
						<div class="col-lg-12">
							<div class="card" v-if="user">
								<div class="card-header border-0">
									<div class="d-flex justify-content-between">
										<h3 class="card-title">Analytics <span id="selectedSiteURL"></span></h3>
									</div>
								</div>
								<div class="card-body">
									<div class="position-relative mb-4">
										<div id="ajax-loading">Please Wait...</div>
										<vue3-chart-js
											:id="analyticsChart.id"
											ref="analyticsChartRef"
											:type="analyticsChart.type"
											:data="analyticsChart.data"
											:options="analyticsChart.options"
											@before-render="beforeRenderLogic"
										></vue3-chart-js>
									</div>

									<div class="d-flex flex-row justify-content-end">
										<span class="mr-2">
											<i class="fas fa-square text-primary"></i>
										</span>
									</div>
								</div>								
							</div>
							<div class="card alert alert-danger alert-dismissible" v-if="!user">	
								<strong>Please login to access this page!</strong>
							</div>					
						</div>					
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
    import AppHeader from "../../Partials/AppHeader";
    import AppSidebar from "../../Partials/AppSidebar";
    import ErrorsAndMessages from "../../Partials/ErrorsAndMessages";
	import Vue3ChartJs from '@j-t-mcc/vue3-chartjs';

    import {Inertia} from "@inertiajs/inertia";
	import {computed} from "vue";
	import { ref } from 'vue'
    import { usePage, Link } from '@inertiajs/inertia-vue3'
    import {reactive,inject} from 'vue';
	
    export default {
        name: "Dashboard",
		created () {
			document.title = 'SeoStack - Dashboard';
		},			
        components: {
			Link,
            ErrorsAndMessages,
            AppHeader,
			AppSidebar,
			Vue3ChartJs
        },
        props: {
            errors: Object
        },
        setup() {
			const analyticsChartRef = ref(null)
			var analyticsChart = "";
			var years = new Array();
			var clicks = new Array();
			var impressions = new Array();
			var ctrs = new Array();
			var positions = new Array();
			var mode = 'index';
			var intersect = false;				
			var chartStatus = 0;
			var ticksStyle = {
				fontColor: '#495057',
				fontStyle: 'bold'
			};
			var baseURL = jQuery("#baseURL").val();
			const route = inject('$route');
			const user = computed(() => usePage().props.value.auth.user);
			const records = usePage().props.value.siteData;
			getSiteRelatedDataFunc(records);
			setTimeout(function(){
				setSiteURLFunc(jQuery("#selectedSite option:selected").text());
			}, 1000);
			
			jQuery(document).on("click", "#selectedSiteDetails", function(){
				Inertia.get(jQuery(this).attr("href"), [], {});
				return false;
			});
			
			jQuery(document).on("change", "#selectedSite", function(){
				var siteURL = jQuery("#selectedSite option:selected").text();
				jQuery("#ajax-loading").css("display", "flex");
				const postData = reactive({
					site: siteURL,
					_token: usePage().props.value.csrf_token
				});				
				
				Inertia.post(route('showSingleSiteDetails'), postData, {
					onSuccess: (response) => {
						setSiteURLFunc(siteURL);
						getSiteRelatedDataFunc(response.props.siteData, 1);
						jQuery("#ajax-loading").css("display", "none");
					},
					onError: (errors) => {
						alert("errors");
					}
				});
				return false;
			});	
			
			function setSiteURLFunc(siteURL){				
				jQuery("#selectedSiteURL").html("<a id='selectedSiteDetails' href='"+baseURL+"/details/"+btoa(siteURL)+"'>("+siteURL+")</a>");			
			}
			
			function getSiteRelatedDataFunc(records, isUpdate=0){
				var totalRecords = records.length;				
				if(totalRecords){
					for(var counter=0; counter<totalRecords; counter++){
						years[counter] = records[counter].date;
						clicks[counter] = records[counter].clicks;
						impressions[counter] = records[counter].impressions;
						ctrs[counter] = records[counter].ctr;
						positions[counter] = records[counter].position;
					}
					
					analyticsChart = {
						data: {
							labels: years,
							datasets: [{
								label: 'Clicks',
								type: 'line',
								data: clicks,
								backgroundColor: 'transparent',
								borderColor: '#007bff',
								pointBorderColor: '#007bff',
								pointBackgroundColor: '#007bff',
								fill: false,
								pointRadius: 0
							}]
						},
						options: {
							responsive: false,
							maintainAspectRatio: false,
							interaction: {
								intersect: false
							},
							hover: {
								mode: mode,
								intersect: intersect
							},
							plugins: {
								legend: {
									display: false
								},
								tooltips: {
									mode: mode,
									intersect: intersect,		
								}						
							}
						}
					};		
					
					if(isUpdate == 1){
						analyticsChartRef.value.update();					
					}
				}
			}		

			const beforeRenderLogic = (event) => {
			}			
			
			return {
				user,
				analyticsChart,
				analyticsChartRef,
				beforeRenderLogic
            }
        }
    }
</script>

<style scoped>
	canvas {
		min-height: 200px;
		min-width: 100%;
	}
</style>