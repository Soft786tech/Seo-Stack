<template>
	<div class="wrapper testClass">
		<app-header></app-header>
		<app-sidebar></app-sidebar>
		<div class="content-wrapper">
			<div class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
							<h1 class="m-0">Dashboard for <span class="selectedSiteURL"></span></h1>
						</div>
					</div>
				</div>
			</div>
			<div class="content">
				<div class="container-fluid">
					<div class="row">			
						<div class="col-lg-12">
							<div class="analytics-warpper"  v-if="user">
								<div class="card">
									<div class="card-header border-0">
										<div class="d-flex justify-content-between">
											<h3 class="card-title">Clicks Per Day</h3>
										</div>
									</div>	
									<div class="card-body">
										<div class="position-relative mb-4">
											<div id="ajax-loading">Please Wait...</div>
											<vue3-chart-js
												:id="analyticsClicksChart.id"
												:type="analyticsClicksChart.type"
												:data="analyticsClicksChart.data"
												:options="analyticsClicksChart.options"
												@before-render="beforeRenderLogic"
											></vue3-chart-js>
										</div>

										<div class="d-flex flex-row justify-content-end">
											<span class="mr-2">
												<i class="fas fa-square text-primary"></i>
											</span>
										</div>
									</div>								
								</div>
								
								<div class="card">
									<div class="card-header border-0">
										<div class="d-flex justify-content-between">
											<h3 class="card-title">Impressions Per Day</h3>
										</div>
									</div>	
									<div class="card-body">
										<div class="position-relative mb-4">
											<vue3-chart-js
												:id="analyticsImpressionsChart.id"
												:type="analyticsImpressionsChart.type"
												:data="analyticsImpressionsChart.data"
												:options="analyticsImpressionsChart.options"
												@before-render="beforeRenderLogic"
											></vue3-chart-js>
										</div>

										<div class="d-flex flex-row justify-content-end">
											<span class="mr-2">
												<i class="fas fa-square text-primary"></i>
											</span>
										</div>
									</div>								
								</div>								
								
								<div class="card">
									<div class="card-header border-0">
										<div class="d-flex justify-content-between">
											<h3 class="card-title">Average Page Position</h3>
										</div>
									</div>	
									<div class="card-body">
										<div class="position-relative mb-4">
											<vue3-chart-js
												:id="analyticsPositionChart.id"
												:type="analyticsPositionChart.type"
												:data="analyticsPositionChart.data"
												:options="analyticsPositionChart.options"
												@before-render="beforeRenderLogic"
											></vue3-chart-js>
										</div>

										<div class="d-flex flex-row justify-content-end">
											<span class="mr-2">
												<i class="fas fa-square text-primary"></i>
											</span>
										</div>
									</div>								
								</div>								
								
								<div class="card">
									<div class="card-header border-0">
										<div class="d-flex justify-content-between">
											<h3 class="card-title">Average Site CTR</h3>
										</div>
									</div>	
									<div class="card-body">
										<div class="position-relative mb-4">
											<vue3-chart-js
												:id="analyticsCTRChart.id"
												:type="analyticsCTRChart.type"
												:data="analyticsCTRChart.data"
												:options="analyticsCTRChart.options"
												@before-render="beforeRenderLogic"
											></vue3-chart-js>
										</div>

										<div class="d-flex flex-row justify-content-end">
											<span class="mr-2">
												<i class="fas fa-square text-primary"></i>
											</span>
										</div>
									</div>								
								</div>
							</div>
							<div class="card alert alert-danger alert-dismissible" v-if="!user">	
								<strong>Please login to access this page!</strong>
							</div>					
						</div>					
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
    import AppHeader from "../../Partials/AppHeader";
    import AppSidebar from "../../Partials/AppSidebar";
    import ErrorsAndMessages from "../../Partials/ErrorsAndMessages";
	import Vue3ChartJs from '@j-t-mcc/vue3-chartjs';

    import {Inertia} from "@inertiajs/inertia";
	import {computed} from "vue";
	import { ref } from 'vue'
    import { usePage } from '@inertiajs/inertia-vue3'
    import {reactive,inject} from 'vue';
	
    export default {
        name: "SiteDetails",
		created () {
			
		},			
        components: {
            ErrorsAndMessages,
            AppHeader,
			AppSidebar,
			Vue3ChartJs
        },
        props: {
            errors: Object
        },
        setup() {
			var analyticsClicksChart = "";
			var analyticsImpressionsChart = "";
			var analyticsPositionChart = "";
			var analyticsCTRChart = "";
			var years = new Array();
			var clicks = new Array();
			var impressions = new Array();
			var ctrs = new Array();
			var positions = new Array();
			var mode = 'index';
			var intersect = false;				
			var chartStatus = 0;
			var baseURL = jQuery("#baseURL").val();
			var ticksStyle = {
				fontColor: '#495057',
				fontStyle: 'bold'
			};
			
			const user = computed(() => usePage().props.value.auth.user);
			const records = usePage().props.value.siteData;
			const site = usePage().props.value.site;
			
			document.title = 'SeoStack - ('+site+') Details';
			
			getSiteRelatedDataFunc(records);
			setTimeout(function(){
				setSiteURLFunc(site);
			}, 1000);
			
			function setSiteURLFunc(siteURL){				
				jQuery(".selectedSiteURL").html("<a href='"+baseURL+"/details/"+btoa(siteURL)+"'>("+siteURL+")</a>");			
			}
			
			function getSiteRelatedDataFunc(records){
				var totalRecords = records.length;				
				if(totalRecords){
					for(var counter=0; counter<totalRecords; counter++){
						years[counter] = records[counter].date;
						clicks[counter] = records[counter].clicks;
						impressions[counter] = records[counter].impressions;
						positions[counter] = records[counter].position;
						ctrs[counter] = records[counter].ctr;
					}
					
					analyticsClicksChart = renderAnalyticChartFunc(years, clicks, "Clicks Per Day");							
					analyticsImpressionsChart = renderAnalyticChartFunc(years, impressions, "Impressions Per Day");						
					analyticsPositionChart = renderAnalyticChartFunc(years, positions, "Average Page Position");
					analyticsCTRChart = renderAnalyticChartFunc(years, ctrs, "Average CTR");
				}
			}		

			function renderAnalyticChartFunc(years, data, label){
				return {
					data: {
						labels: years,
						datasets: [{
							label: label,
							type: 'line',
							data: data,
							backgroundColor: 'transparent',
							borderColor: '#007bff',
							pointBorderColor: '#007bff',
							pointBackgroundColor: '#007bff',
							fill: false,
							pointRadius: 0
						}]
					},
					options: {
						responsive: false,
						maintainAspectRatio: false,
						interaction: {
							intersect: false
						},
						hover: {
							mode: mode,
							intersect: intersect
						},
						plugins: {
							legend: {
								display: false
							},
							tooltips: {
								mode: mode,
								intersect: intersect,		
							}						
						}
					}
				};				
			}
			
			const beforeRenderLogic = (event) => {
			}			
			
			const form = reactive({
				email: null,
				password: null,
				_token: usePage().props.value.csrf_token
            });
			
            const route = inject('$route');

            function submit() {
                Inertia.post(route('siteDetails'), form);
            }

            return {
				user,
                form, 
				submit,
				analyticsClicksChart,
				analyticsImpressionsChart,
				analyticsPositionChart,
				analyticsCTRChart,
				beforeRenderLogic
            }
        }
    }
</script>

<style scoped>
    form {
        margin-top: 20px;
    }
	canvas {
		min-height: 200px;
		min-width: 100%;
	}
</style>