<template>
	<div class="hold-transition login-page">
		<div class="login-box">
			<div class="card card-outline card-primary">
				<div class="card-header text-center">
					<a href="/" class="h1"><b>Seo</b>Stack</a>
				</div>
				<div class="card-body">
					<p>Welcome {{username}}</p>
					<form method="post" @submit.prevent="submit">
						
                     <h5>Your Request Is Pending Plz Wait for confirmation from the <b>admin</b><br>we will inform you by the E-mail Thank You</h5>                    
                      
                      <div class="col-12">
								<div class="icheck-primary signup">
									
									<a href="login">Back</a>
									
								</div>
					  </div>
				
					</form>
				</div>
			</div>
		</div>
    </div>
</template>

<script>

    import {Inertia} from "@inertiajs/inertia";
    import { usePage } from '@inertiajs/inertia-vue3'
    import {reactive,inject} from 'vue';

export default {
   name: 'verify-email',

   setup(props) {
		
		const username = usePage().props.value.username;	
				
        return {
            username,
			
        }		
	}
}
</script>

<style scoped>
form {
        margin-top: 20px;
    }
	.signup{
		float: right;
}
p{
    color: #007bff;
    text-align: center;
	
}
</style>
