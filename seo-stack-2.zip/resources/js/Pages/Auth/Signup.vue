<template>
	<div class="hold-transition login-page">
		<div class="login-box">
			<div class="card card-outline card-primary">
				<div class="card-header text-center">
					<a href="/" class="h1"><b>Seo</b>Stack</a>
				</div>
				<div class="card-body">
					<p class="login-box-msg">Sign Up to start your session</p>
					<form method="post" @submit.prevent="submit">
						<errors-and-messages :errors="errors"></errors-and-messages>
						<input type="hidden" name="_token" :value="csrf">


                        <div class="input-group mb-3">
							<input type="text" class="form-control" name="name" id="name" v-model="form.name" />
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-user"></span>
								</div>
							</div>
						</div>
                        

						<div class="input-group mb-3">
							<input type="text" class="form-control" name="email" id="email" v-model="form.email" />
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-envelope"></span>
								</div>
							</div>
						</div>

						<div class="input-group mb-3">
							<input type="password" class="form-control" name="password" id="password" v-model="form.password" />
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-lock"></span>
								</div>
							</div>
						</div>

						<div class="row">
						


                           <div class="col-12">
								<div class="icheck-primary signup">
									
									<a href="login">Back</a>
									
								</div>
							</div>


						</div>
						<div class="col-4">
							<input type="submit" class="btn btn-primary btn-block" value="SignUp" />
						</div>
					</form>
				</div>
			</div>
		</div>
    </div>
</template>


<script>
    import AppHeader from "../../Partials/AppHeader";
    import ErrorsAndMessages from "../../Partials/ErrorsAndMessages";
    import {Inertia} from "@inertiajs/inertia";
    import { usePage } from '@inertiajs/inertia-vue3'
    import {reactive,inject} from 'vue';

    export default {
        name: "Signup",
		created () {
			document.title = 'SeoStack - Login'
		},
        components: {
            ErrorsAndMessages,
            AppHeader
        },
        props: {
            errors: Object
        },
        data() {
			return {
				csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content')
			}
		},
        setup() {
            const form = reactive({
               name: null,
               email: null,
               password: null,
               _token: usePage().props.value.csrf_token,
            });

            const route = inject('$route');

            function submit() {
                Inertia.post(route('signupAuthenticate'), form);
            }

            return {
                form, submit
            }
        }
    }
</script>

<style scoped>
    form {
        margin-top: 20px;
    }
	.signup{
		text-align: center;
}
</style>