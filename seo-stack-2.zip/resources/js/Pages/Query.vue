<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2" v-if="user">
            <div class="col-sm-4">
              <h1 class="m-0">Query Row Count Tool</h1>
            </div>
            <div class="col-sm-8 filter-warpper">
				<filters-listing></filters-listing>
				<date-filter></date-filter>
				<query-filter></query-filter>
				<page-filter></page-filter>
				<country-filter></country-filter>
            </div>
        </div>
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12">
              <div class="card" v-if="user">
                <div class="card-header border-0">
                  <div class="d-flex justify-content-between">
                    <h3 class="card-title">
                      <!-- Analytics
                      <span id="selectedSitectURL"></span> -->
                    </h3>
                    <div v-if="sites.length > 0 && user">
                      <select class="select2 form-control" id="selectedSitect" name="selectedSitect">
                        <option v-for="site in sites" :key="site">{{site}}</option>
                      </select>
                      
                    </div>
                    <form id="export-site-data-form" action="" target="_blank" method="post">
                      <input type="hidden" name="_token" id="_token" />
                      <input type="hidden" name="site" id="site" />
                      <input type="hidden" name="filterByDays" id="exportFilterByDays" />
                      <input type="hidden" name="startDate" id="exportStartDate" />
                      <input type="hidden" name="endDate" id="exportEndDate" />
                      <input type="hidden" name="keyword" id="exportKeyword" />
                      <input type="hidden" name="queryFilter" id="exportQueryFilter" />
                      <input type="hidden" name="pageURL" id="exportPageURL" />
                      <input type="hidden" name="pageFilter" id="exportPageFilter" />
                      <input type="hidden" name="country" id="exportCountry" />
                      <input type="submit" class="btn btn-block btn-dark btn-sm" value="Export" />
                    </form>
                  </div>
                </div>
                <div class="card-body">
                  <div id="ajax-loading">Please Wait...</div>                  
                </div>
				      	<query-table></query-table>
              </div>
              <div class="card alert alert-danger alert-dismissible" v-if="!user">
                <strong>Please login to access this page!</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

let mainObj;
import AppHeader from "../Partials/AppHeader";
import AppSidebar from "../Partials/AppSidebar";
import FiltersListing from "../Partials/Filters/FiltersListingTool";
import DateFilter from "../Partials/Filters/DateFilterTool";
import QueryFilter from "../Partials/Filters/QueryFilterTool";
import PageFilter from "../Partials/Filters/PageFilterTool";
import CountryFilter from "../Partials/Filters/CountryFilterTool";
import QueryTable from "../Pages/QueryTool"; 
import ErrorsAndMessages from "../Partials/ErrorsAndMessages";
import Vue3ChartJs from "@j-t-mcc/vue3-chartjs";
import { Inertia } from "@inertiajs/inertia";
import { computed } from "vue";
import { ref } from "vue";
import { usePage, Link } from "@inertiajs/inertia-vue3";
import { reactive, inject } from "vue";

export default {
    name: "Query",
    created() {
      mainObj = this;
      document.title = "SeoStack - Query Tool";
    },
    components: {
      Link,
      ErrorsAndMessages,
      AppHeader,
      AppSidebar,
      FiltersListing,
      DateFilter,
      QueryFilter,
      PageFilter,
      CountryFilter,
      QueryTable,
      Vue3ChartJs,
    },
    props: {
      errors: Object,
      startDate:Object,
      endDate:Object
    },
    
    setup(props) {
        const analyticsChartRef = ref(null);
        var analyticsChart = "";
        var years = new Array();
        var clicks = new Array();
        var impressions = new Array();
        var ctrs = new Array();
        var positions = new Array();
        var mode = "index";
        var intersect = false;
        var chartStatus = 0;
        var ticksStyle = {
            fontColor: "#495057",
            fontStyle: "bold",
        };
        var baseURL = jQuery("#baseURL").val();
        const route = inject("$route");
        const user = computed(() => usePage().props.value.auth.user);
        const sites = computed(() => usePage().props.value.sites);
        const getData = usePage().props.value.getData;
        const records = usePage().props.value.siteData;
      
        var click_per_day_legend = false;
        var impressions_per_day_legend = false;
        var Averarge_page_position_legend = false;
        var avrg_site_ctr = false;
		    var currentLocation = window.location.href;
				
        getSiteRelatedDataFunc(records);
		
        setTimeout(function () {
          var selectedSitectURI = jQuery("#selectedSitect option:selected").text();
          
          if(
            typeof getData['url'] !== "undefined" &&
            getData['url'] != null
          ){
            selectedSitectURI = getData['url'];
          }			

          jQuery("form#export-site-data-form").attr("action", baseURL+"/export-query-row-data");
          
          jQuery("#_token").val(usePage().props.value.csrf_token);
          jQuery("#site").val(((typeof getData['url'] !== "undefined") ? getData['url'] : selectedSitectURI));
          jQuery("#exportFilterByDays").val(((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : "last6Months"));
          jQuery("#exportKeyword").val(((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""));
          jQuery("#exportQueryFilter").val(((typeof getData['queryFilter'] !== "undefined") ? getData['queryFilter'] : ""));
          jQuery("#exportPageFilter").val(((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""));
          jQuery("#exportPageURL").val(((typeof getData['url'] !== "undefined") ? getData['url'] : ""));
          jQuery("#exportCountry").val(((typeof getData['country'] !== "undefined") ? getData['country'] : ""));
          jQuery("#exportStartDate").val(((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""));
          jQuery("#exportEndDate").val(((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""));

          setSiteURLFunc(selectedSitectURI, ((typeof getData['defaultSiteURL'] !== "undefined") ? getData['defaultSiteURL'] : ""));
          if (window.location.href.indexOf("?") > -1) {
            history.pushState("", document.title, window.location.pathname);
          }
        }, 1000);
		
        jQuery(document).on("change", "#selectedSitect", function () {
            var siteURL = jQuery("#selectedSitect option:selected").text();
            jQuery("#ajax-loading").css("display", "flex");
            const postData = reactive({
                site: siteURL,
                _token: usePage().props.value.csrf_token,
            });
            console.log('hello');
            Inertia.post(route("showSingleSiteDetailsQuery"), postData, {
                onSuccess: (response) => {
                    setSiteURLFunc(siteURL);
                    mainObj.getSiteKeywordsRelatedDataFunc(response.props.siteData, mainObj);
                    jQuery("#site").val(siteURL);
                    jQuery("#ajax-loading").css("display", "none");
                },
                onError: (errors) => {
                  alert("errors");
                },
            });
            return false;
        });

        function setSiteURLFunc(siteURL, defaultSiteURL="") {
            jQuery("#selectedSitectURL").html("<a id='selectedSitectDetails' href='"+baseURL+"/details/"+btoa(siteURL)+"'>(" +siteURL+")</a>");
            setTimeout(function(){
              defaultSiteURL = (siteURL != defaultSiteURL && defaultSiteURL != "") ? defaultSiteURL : siteURL;
              jQuery('#selectedSitect').val(defaultSiteURL);
              jQuery('#selectedSitect').select2('destroy');
              jQuery('#selectedSitect').val(defaultSiteURL).select2();            
            }, 1000);
        }

        function getSiteRelatedDataFunc(records, isUpdate = 0) {

            var totalRecords = records.length;
            if (totalRecords) {
                for (var counter = 0; counter < totalRecords; counter++) {
                    years[counter] = records[counter].date;
                    clicks[counter] = records[counter].clicks;
                    impressions[counter] = records[counter].impressions;
                    ctrs[counter] = records[counter].ctr;
                    positions[counter] = records[counter].position;
                }

                analyticsChart = {
                    type: "line",
                    data: {
                        labels: years,
                        datasets: [
                            {
                                
                                label: "Clicks Per Day",
                                yAxisID: 'Clicks Per Day',
                                type: "line",
                                data: clicks,
                                backgroundColor: "transparent",
                                borderColor: "#007bff",
                                pointBorderColor: "#007bff",
                                pointBackgroundColor: "#007bff",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },
                            { 
                               
                                label: "Impressions Per Day",
                                //yAxisID: 'Impressions Per Day',
                                data: impressions,
                                backgroundColor: "transparent",
                                borderColor: "#6610f2",
                                pointBorderColor: "#6610f2",
                                pointBackgroundColor: "#6610f2",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },
                            {
                                label: "Average Page Position",
                                type: "line",
                                data: positions,
                                backgroundColor: "transparent",
                                borderColor: "#309f6c",
                                pointBorderColor: "#309f6c",
                                pointBackgroundColor: "#309f6c",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },
                            {
                                label: "Average Site CTR",
                                type: "line",
                                data: ctrs,
                                backgroundColor: "transparent",
                                borderColor: "#cb880f",
                                pointBorderColor: "#cb880f",
                                pointBackgroundColor: "#cb880f",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },



                        ],



                    },
                    options: {

                               scales: {

                                      yAxis: {
                                      id:  'Clicks Per Day',
                                     type: 'linear',
                                     position: 'right',      
                                             }, 
          
                                 },

          
                        responsive: false,
                        maintainAspectRatio: false,
                        interaction: {
                            intersect: false,
                        },
                        hover: {
                            mode: mode,
                            intersect: intersect,
                        },
                        plugins: {
                            legend: {
                                display: false,
                            },
                            tooltips: {
                                mode: mode,
                                intersect: intersect,
                            },
                        },
                    },
                };

                if (isUpdate == 1) {
                    analyticsChartRef.value.update();
                }
            }
        }

        const beforeRenderLogic = (event) => {};





        return {
            user,
            analyticsChart,
            analyticsChartRef,
            beforeRenderLogic,
            click_per_day_legend,
            impressions_per_day_legend,
            Averarge_page_position_legend,
            avrg_site_ctr,
            sites,
        };
    },
  methods: {
		getSiteKeywordsRelatedDataFunc(records, dashboardObj){			
			var totalRecords = records.length;
			
      if (totalRecords) {
				var keywordYears = new Array();
				var keywordClicks = new Array();
				var keywordImpressions = new Array();
				var keywordCtrs = new Array();
				var keywordPositions = new Array();		
				
        for (var counter = 0; counter < totalRecords; counter++) {
            keywordYears[counter] = records[counter].date;
            keywordClicks[counter] = records[counter].clicks;
            keywordImpressions[counter] = records[counter].impressions;
            keywordPositions[counter] = records[counter].position;
            keywordCtrs[counter] = records[counter].ctr;
        }
			}				
			
			dashboardObj.analyticsChart.data.labels = keywordYears;
			dashboardObj.analyticsChart.data.datasets[0].data = keywordClicks;
			dashboardObj.analyticsChart.data.datasets[1].data = keywordImpressions;
			dashboardObj.analyticsChart.data.datasets[2].data = keywordPositions;
			dashboardObj.analyticsChart.data.datasets[3].data = keywordCtrs;
			// dashboardObj.analyticsChartRef.update();
		},      
    getDefaultSiteKeywordsRelatedDataFunc(dashboardObj){
      this.getSiteKeywordsRelatedDataFunc(usePage().props.value.siteData, dashboardObj);
    },     
    toggleValue(e) {
        if (e == 0) {
            this.click_per_day_legend = !this.click_per_day_legend;
            this.analyticsChart.data.datasets[e].hidden = this.click_per_day_legend;
        }
        if (e == 1) {
            this.impressions_per_day_legend = !this.impressions_per_day_legend;
            this.analyticsChart.data.datasets[e].hidden = this.impressions_per_day_legend;
        }
        if (e == 2) {
            this.Averarge_page_position_legend = !this.Averarge_page_position_legend;
            this.analyticsChart.data.datasets[e].hidden = this.Averarge_page_position_legend;
        }
        if (e == 3) {
            this.avrg_site_ctr = !this.avrg_site_ctr;
            this.analyticsChart.data.datasets[e].hidden = this.avrg_site_ctr;
        }

        this.analyticsChartRef.update();
    },
    numberFormater(num) {
      return Math.abs(num) > 999
      ? Math.sign(num) * (Math.abs(num) / 1000).toFixed(1) + "k"
      : Math.sign(num) * Math.abs(num);
    },
  }
};






</script>

<style scoped>
canvas {
  min-height: 200px;
  min-width: 100%;
}
.box_1 {
  background: rgb(119, 193, 223);
  padding: 2.6% 2% 0% 2%;
  border-top-left-radius: 25px;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}

.box_2 {
  background: #6610f2;
  padding: 2.6% 2% 0% 2%;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.box_3 {
  background: #309f6c;
  padding: 2.6% 2% 0% 2%;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.box_4 {
  background: #cb880f;
  padding: 2.6% 2% 0% 2%;
  border-top-right-radius: 25px;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.cpd .ipd .apps .ast {
  font-size: 30px !important;
  padding: 0px 6px 0px 6px;
  line-height: 1;
  margin-bottom: 0px;
}
.clicktext {
  color: rgb(119, 193, 223);
}
.Impressionstext {
  color: #6610f2;
}
.Positionstext {
  color: #309f6c;
}
.ctrtext {
  color: #cb880f;
}
.content-header{
  background:#f4f6f9 ;
  position: sticky;
  top: 0;
  z-index: 1100;
}
.head{
  display: flex;
}
.click{
  width: 50%;
  font-weight: bold;
}
.impression{
  width: 50%;
  text-align: right;
  font-weight: bold;
}


</style>