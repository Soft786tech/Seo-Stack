<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-md-12">
              <div id="loading">
                <span class="textloader">Please Wait...</span>
              </div>

              <div class="">
                <div class="py-3 px-2">
                  <div class="text-right">
                    <div
                      v-if="$page.props.errors.errors"
                      class="text-center alert alert-danger"
                      role="alert"
                    >
                      {{ $page.props.errors.errors }}
                    </div>
                    <div
                      v-if="$page.props.flash.success"
                      class="text-center alert alert-success"
                      role="alert"
                    >
                      {{ $page.props.flash.success }}
                    </div>
                  </div>
                  <h1 class="pb-2">Authorize</h1>

                  <form @submit.prevent="googleSearchConsoleOAuth" method="post">
                    <div class="form-group">
                      <span for="userOAuth">Authorize Google Search Console Account</span>
                      <input
                        type="hidden"
                        name="userOAuth"
                        required
                        value="1"
                        class="form-control"
                        id="userOAuth"
                        aria-describedby="userOAuth"
                      />
                    </div>
                    <div class="form-group">
                      <button type="submit" class="btn btn-primary">
                        Authorize
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
 import AppHeader from "../Partials/AppHeader.vue";
 import AppSidebar from "../Partials/AppSidebar.vue";
    import {  Link } from '@inertiajs/inertia-vue3'

export default {
    name:'main',
    created () {
			document.title = 'SeoStack - Google Search Console OAuth';
		},
    components:{
        Link,
        AppHeader,
        AppSidebar,
    },
   data: function () {
    return {
        data:{
          userOAuth: 1
        }
    }
    },

methods:{
      googleSearchConsoleOAuth(){
        jQuery('#loading').css('display','block');
        jQuery('.textloader').css('display','block');

        var data = {
          formData: this.data
        };

        jQuery.post(jQuery("#baseURL").val()+"/public/google-search-console-auth/google-search-console.py", data, function(response){
          console.log(response);  
        }); 
      },  
      googleSearchConsoleOAuth1(){
        jQuery('#loading').css('display','block');
        jQuery('.textloader').css('display','block');
        this.$inertia.post(route('googleSearchConsoleOAuth'), this.data, {
          onSuccess: (response) => {
            jQuery('#loading').css("display", "none");
            jQuery('.textloader').css("display", "none");
            console.log(response);
					},
					onError: (errors) => {
            jQuery('#loading').css("display", "none");
            jQuery('.textloader').css("display", "none");
            console.log(errors);
					}
				});

        this.data={}
      }
  }

}
</script>
<style>
#loading {
  display: none;
  background: #584c38;
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 1;
  opacity: 0.3;
}
.textloader {
  display: none;
  width: 100%;
  color: white;
  position: absolute;
  top: 10%;
  font-size: 30px;
  text-align: -webkit-center;
}
</style>
