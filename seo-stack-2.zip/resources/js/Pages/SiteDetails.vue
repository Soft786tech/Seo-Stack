<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header" v-if="user">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 font">
                Dashboard for <span class="selectedSiteURL"></span>
              </h1>
            </div>

            <div class="col-sm-6" v-if="sitePages">
              <h1>Site Pages</h1>
              <select class="select2" id="selectedSite" name="selectedSite">
                <option v-for="sitePage in sitePages" :key="sitePage">
                  {{sitePage}}
                </option>
              </select>
            </div>
            <div class="col-sm-12 filter-warpper">
				<filters-listing></filters-listing>
				<date-filter></date-filter>
				<query-filter></query-filter>
				<page-filter></page-filter>
				<country-filter></country-filter>
			</div>
          </div>
        </div>
      </div>
      <div class="content" v-if="user">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12">
              <div class="analytics-warpper" v-if="user">
                <div id="ajax-loading">Please Wait...</div>
                <div class="card">
                  <div class="card-header border-0">
                    <div class="d-flex justify-content-between">
                      <h3 class="card-title">Clicks Per Day</h3>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="position-relative mb-4">
                      <vue3-chart-js
                        :id="analyticsClicksChart.id"
                        :type="analyticsClicksChart.type"
                        :data="analyticsClicksChart.data"
                        :options="analyticsClicksChart.options"
                        @before-render="beforeRenderLogic"
                        style="position: relative; height: 55vh; width: 70vw"
                      ></vue3-chart-js>
                    </div>

                    <div class="d-flex flex-row justify-content-end">
                      <span class="mr-2">
                        <i class="fas fa-square text-primary"></i>
                      </span>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header border-0">
                    <div class="d-flex justify-content-between">
                      <h3 class="card-title">Impressions Per Day</h3>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="position-relative mb-4">
                      <vue3-chart-js
                        :id="analyticsImpressionsChart.id"
                        :type="analyticsImpressionsChart.type"
                        :data="analyticsImpressionsChart.data"
                        :options="analyticsImpressionsChart.options"
                        @before-render="beforeRenderLogic"
                        style="position: relative; height: 55vh; width: 70vw"
                      ></vue3-chart-js>
                    </div>

                    <div class="d-flex flex-row justify-content-end">
                      <span class="mr-2">
                        <i class="fas fa-square text-primary"></i>
                      </span>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header border-0">
                    <div class="d-flex justify-content-between">
                      <h3 class="card-title">Average Page Position</h3>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="position-relative mb-4">


                    <div class="head">
                            <div class="click">
                               Clicks
                             </div>
                            <div class="impression">
                               Impressions
                            </div>
                    </div>
                  

                      <vue3-chart-js
                        :id="analyticsPositionChart.id"
                        :type="analyticsPositionChart.type"
                        :data="analyticsPositionChart.data"
                        :options="analyticsPositionChart.options"
                        @before-render="beforeRenderLogic"
                        style="position: relative; height: 55vh; width: 70vw"
                      ></vue3-chart-js>
                    </div>

                    <div class="d-flex flex-row justify-content-end">
                      <span class="mr-2">
                        <i class="fas fa-square text-primary"></i>
                      </span>
                    </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header border-0">
                    <div class="d-flex justify-content-between">
                      <h3 class="card-title">Average Site CTR</h3>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="position-relative mb-4">
                      <vue3-chart-js
                        :id="analyticsCTRChart.id"
                        :type="analyticsCTRChart.type"
                        :data="analyticsCTRChart.data"
                        :options="analyticsCTRChart.options"
                        @before-render="beforeRenderLogic"
                        style="position: relative; height: 55vh; width: 70vw"
                      ></vue3-chart-js>
                    </div>

                    <div class="d-flex flex-row justify-content-end">
                      <span class="mr-2">
                        <i class="fas fa-square text-primary"></i>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card">
				<query-table></query-table>
			  </div>
            </div>
          </div>
        </div>
      </div>
	  <div class="card alert alert-danger alert-dismissible" v-if="!user">
		<strong>Please login to access this page!</strong>
	  </div>	  
    </div>
  </div>
</template>

<script>
	import AppHeader from "../Partials/AppHeader";
	import AppSidebar from "../Partials/AppSidebar";
	import FiltersListing from "../Partials/Filters/FiltersListing";
	import DateFilter from "../Partials/Filters/DateFilter";
	import QueryFilter from "../Partials/Filters/QueryFilter";
	import PageFilter from "../Partials/Filters/PageFilter";
	import CountryFilter from "../Partials/Filters/CountryFilter";   
	import QueryTable from "../Pages/QueryTable";   
	import ErrorsAndMessages from "../Partials/ErrorsAndMessages";
	import Vue3ChartJs from '@j-t-mcc/vue3-chartjs';

	import {Inertia} from "@inertiajs/inertia";
	import {computed} from "vue";
	import { ref } from 'vue'
	import { usePage } from '@inertiajs/inertia-vue3'
	import {reactive,inject} from 'vue';

	export default {
       name: "SiteDetails",
		created () {
		},
       components: {
			ErrorsAndMessages,
			AppHeader,
			AppSidebar,
			FiltersListing,
			DateFilter,
			QueryFilter,
			PageFilter,
			CountryFilter,	
			QueryTable,	
			Vue3ChartJs
		},
		props: {
			errors: Object,
			siteData:Object,
			sitePages:Object,
            startDate:Object,
			endDate:Object
		},
		setup(props) {
			var analyticsClicksChart = "";
			var analyticsImpressionsChart = "";
			var analyticsPositionChart = "";
			var analyticsCTRChart = "";
			var years = new Array();
			var clicks = new Array();
			var impressions = new Array();
			var ctrs = new Array();
			var positions = new Array();
			var mode = 'index';
			var intersect = false;
			var chartStatus = 0;
			var baseURL = jQuery("#baseURL").val();
			var checkNumStatus = 0;
			var ticksStyle = {
				fontColor: '#495057',
				fontStyle: 'bold'
			};
			const user = computed(() => usePage().props.value.auth.user);
			const sitePages = computed(() => usePage().props.value.sitePages);
			const keywords = computed(() => usePage().props.value.keywords);
			const totalPages = computed(() => usePage().props.value.totalPages);
			const records = usePage().props.value.siteData;
			const site = usePage().props.value.site;
			const mainSite = usePage().props.value.mainSite;
            const keywordDetails = computed(() => usePage().props.value.keywordDetails);
			const pagination = computed(() => usePage().props.value.pagination);
			// const keywordDetails = usePage().props.value.keywordDetails;
			// const pagination = usePage().props.value.pagination;
			const orderBy = usePage().props.value.orderBy;
			const orderState = usePage().props.value.order;
 
            

			document.title = 'SeoStack - ('+site+') Details';
			jQuery("#ajax-loading").css("display", "none");
			
			getSiteRelatedDataFunc(records);
			setTimeout(function(){
				setSiteURLFunc(site);
				jQuery('.select2').select2();
				var currentLocation = window.location.href;

				jQuery("#selectedSite").on("change", function(){
					jQuery("#ajax-loading").css("display", "none");
					Inertia.get(baseURL+"/details/"+btoa(jQuery(this).val())+"/"+btoa(mainSite ? mainSite : site), [], {});
					return false;
				});
			}, 1000);

			setTimeout(function () {
				if (window.location.href.indexOf("?") > -1) {
					history.pushState("", document.title, window.location.pathname);
				}				
				
				setSiteURLFunc(jQuery("#selectedSite option:selected").text());
			}, 100);
			
			function setSiteURLFunc(siteURL){
				jQuery(".selectedSiteURL").html("<a href='"+baseURL+"/details/"+btoa(siteURL)+"'>("+siteURL+")</a>");
			}

			function getSiteRelatedDataFunc(records){
				var totalRecords = records.length;
				if(totalRecords){
					for(var counter=0; counter<totalRecords; counter++){
						years[counter] = records[counter].date;
						clicks[counter] = records[counter].clicks;
						impressions[counter] = records[counter].impressions;
						positions[counter] = records[counter].position;
						ctrs[counter] = records[counter].ctr;
					}

					analyticsClicksChart = renderAnalyticChartFunc(years, clicks, "Clicks Per Day");
					analyticsImpressionsChart = renderAnalyticChartFunc(years, impressions, "Impressions Per Day");
					analyticsPositionChart = renderAnalyticChartFunc(years, positions, "Average Page Position");
					analyticsCTRChart = renderAnalyticChartFunc(years, ctrs, "Average CTR");
				}
			}

			function renderAnalyticChartFunc(years, data, label){
				return {
					data: {
						labels: years,
						datasets: [{
							label: label,
							type: 'line',
							data: data,
							backgroundColor: 'transparent',
							borderColor: '#007bff',
							pointBorderColor: '#007bff',
							pointBackgroundColor: '#007bff',
							fill: false,
							pointRadius: 0,
							tension: 0.5
						}]
					},
					options: {
						responsive: false,
						maintainAspectRatio: false,
						interaction: {
							intersect: false
						},
						hover: {
							mode: mode,
							intersect: intersect
						},
						plugins: {
							legend: {
								display: false
							},
							tooltips: {
								mode: mode,
								intersect: intersect,
							}
						}
					}
				};
			}

			const beforeRenderLogic = (event) => {
			}

			const form = reactive({
				email: null,
				password: null,
				_token: usePage().props.value.csrf_token
			});

			const route = inject('$route');

			function submit() {
               Inertia.post(route('siteDetails'), form);
			}
			return {
				user,
				sitePages,
				form,
				submit,
				analyticsClicksChart,
				analyticsImpressionsChart,
				analyticsPositionChart,
				analyticsCTRChart,
				beforeRenderLogic,
				keywordDetails,
				pagination,
				orderBy,
				orderState,
				totalPages,
				keywords,
				baseURL,
			}
		}
   }
</script>

<style scoped>
form {
  margin-top: 20px;
}
canvas {
  min-height: 200px;
  min-width: 100%;
}
a.selected-page {
  background-color: #007bff;
  color: #fff;
}


.content-header{
	position: sticky;
	top: 0;
	z-index: 1051;
	background-color: #f4f6f9;
}

.font{
	font-size: 1.4rem;
}

</style>