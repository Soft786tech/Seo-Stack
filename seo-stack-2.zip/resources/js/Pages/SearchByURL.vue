<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-12">
              <h1 class="m-0">Search By URL</h1>
              <div class="sites-search-block">
                <form class="form-search-by-urls">
                  <div class="form-group">
                    <div class="input-group input-group-lg">
                      <input
                        class="
                          form-control
                          form-control-navbar
                          form-control
                          form-control-lg
                        "
                        id="searchByURL"
                        type="search"
                        placeholder="Search"
                        aria-label="Search"
                        autocomplete="off"
                      />
                      <div class="search-sites-results card"></div>
                      <div class="input-group-append">
                        <button
                          class="btn btn-lg btn-default"
                          type="submit"
                          id="searchByURLBtn"
                        >
                          <i class="fas fa-search"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
                <p class="text-center searching_list"></p>
              </div>
            </div>
            <div class="col-sm-12 filter-warpper" id="filter">
				<filters-listing></filters-listing>
				<date-filter></date-filter>
				<query-filter></query-filter>
				<page-filter></page-filter>
				<country-filter></country-filter>
			</div>
          </div>
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12">
              <div
                class="card alert alert-warning alert-dismissible"
                id="error-messages"
              >
                <strong class="text-white"></strong>
              </div>
              <div class="card chart-warpper" v-if="user">
                <div class="card-header border-0">
                  <div class="d-flex justify-content-between">
                    <h3 class="card-title">
                      Analytics
                      <span id="selectedSiteURL"></span>
                    </h3>
                  </div>
                </div>
                <div class="card-body">
                  <div class="position-relative mb-4">
                    <div id="ajax-loading">Please Wait...</div>

                    <div class="mainbox">
                      <label
                        for="click_per_day_legend"
                        v-bind:class="click_per_day_legend ? 'box_1' : 'box_1'"
                      >
                        <input
                          type="checkbox"
                          @change="Tooglevalue(0)"
                          name="click_per_day_legend"
                          id="click_per_day_legend"
                          checked="true"
                        />
                        <span class="pl-3">Clicks Per Day</span>
                        <p class="text-white text-center pt-1 cpd mb-0">
                          {{ numberFormater(clicks) }}
                        </p>
                        <p class="p-0 text-right mb-0">
                          <i class="fa fa-question-circle"></i>
                        </p>
                      </label>
                      <label for="impressions_per_day_legend" class="box_2">
                        <input
                          type="checkbox"
                          @change="Tooglevalue(1)"
                          name="impressions_per_day_legend"
                          id="impressions_per_day_legend"
                          checked="true"
                        />
                        <span class="pl-3">Impressions Per Day</span>
                        <p class="text-white text-center ipd pt-1 mb-0">
                          {{
                                                        numberFormater(
                                                            impressions
                                                        )
                          }}
                        </p>
                        <p class="p-0 text-right mb-0">
                          <i class="fa fa-question-circle"></i>
                        </p>
                      </label>
                      <label for="Averarge_page_position_legend" class="box_3">
                        <input
                          type="checkbox"
                          @change="Tooglevalue(2)"
                          name="Averarge_page_position_legend"
                          id="Averarge_page_position_legend"
                          checked="true"
                        />
                        <span class="pl-3">Average Page Position</span>
                        <p class="text-white text-center apps pt-1 mb-0">
                          {{
                                                        numberFormater(
                                                            positionaverage
                                                        )
                          }}
                        </p>
                        <p class="p-0 text-right mb-0">
                          <i class="fa fa-question-circle"></i>
                        </p>
                      </label>
                      <label for="avrg_site_ctr" class="box_4">
                        <input
                          type="checkbox"
                          @change="Tooglevalue(3)"
                          name="avrg_site_ctr"
                          id="avrg_site_ctr"
                          checked="true"
                        />
                        <span class="pl-3">Average Site CTR</span>
                        <p class="text-white text-center ast pt-1 mb-0">
                          {{
                                                        numberFormater(
                                                            averagectr
                                                        )
                          }}
                        </p>

                        <p class="p-0 text-right mb-0">
                          <i class="fa fa-question-circle"></i>
                        </p>
                      </label>
                    </div>


                    <div class="head">
                            <div class="click">
                               Clicks
                             </div>
                            <div class="impression">
                               Impressions
                            </div>
                    </div>
          

                    <vue3-chart-js
                     style="position: relative; height:60vh; width:70vw"
                      :id="analyticsChart.id"
                      ref="analyticsChartRef"
                      :type="analyticsChart.type"
                      :data="analyticsChart.data"
                      :options="analyticsChart.options"
                      @before-render="beforeRenderLogic"
                    ></vue3-chart-js>
                  </div>

                  <div class="d-flex flex-row justify-content-end">
                    <span class="mr-2">
                      <i class="fas fa-square clicktext"></i>
                      Clicks
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-square Impressionstext"></i>
                      Impressions
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-square Positionstext"></i>
                      Positions
                    </span>
                    <span class="mr-2">
                      <i class="fas fa-square ctrtext"></i>
                      CTRS
                    </span>
                  </div>
                </div>
              </div>
              <div
                class="card alert alert-danger alert-dismissible"
                v-if="!user"
              >
                <strong>Please login to access this page!</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import AppHeader from "../Partials/AppHeader";
import AppSidebar from "../Partials/AppSidebar";
import FiltersListing from "../Partials/Filters/FiltersListing";
import DateFilter from "../Partials/Filters/DateFilter";
import QueryFilter from "../Partials/Filters/QueryFilter";
import PageFilter from "../Partials/Filters/PageFilter";
import CountryFilter from "../Partials/Filters/CountryFilter";   
import QueryTable from "../Pages/QueryTable";   
import ErrorsAndMessages from "../Partials/ErrorsAndMessages";
import Vue3ChartJs from "@j-t-mcc/vue3-chartjs";

import { Inertia } from "@inertiajs/inertia";
import { computed } from "vue";
import { ref } from "vue";
import { usePage, Link } from "@inertiajs/inertia-vue3";
import { reactive, inject } from "vue";

export default {
    name: "Dashboard",
    created() {
        document.title = "SeoStack - Dashboard";
    },
    components: {
        Link,
        ErrorsAndMessages,
        AppHeader,
        AppSidebar,
		FiltersListing,
		DateFilter,
		QueryFilter,
		PageFilter,
		CountryFilter,	
		QueryTable,			
        Vue3ChartJs,
    },
    props: {
        errors: Object,
        averagectr: Object,
        positionaverage: Object,
        clicks: Object,
        impressions: Object,
        siteData:Object,
         startDate:Object,
        endDate:Object
    },
    setup(props) {
        const analyticsChartRef = ref(null);
        var analyticsChart = "";
        var years = new Array();
        var clicks = new Array();
        var impressions = new Array();
        var ctrs = new Array();
        var positions = new Array();
        var mode = "index";
        var intersect = false;
        var chartStatus = 0;
        var ticksStyle = {
            fontColor: "#495057",
            fontStyle: "bold",
        };
        var baseURL = jQuery("#baseURL").val();
        const route = inject("$route");
        const user = computed(() => usePage().props.value.auth.user);
        const records = usePage().props.value.siteData;
        var searchStatus = 1;
        var ajaxStatus = 1;
        var typingTimer;
        var doneTypingInterval = 1500;
        var click_per_day_legend = false;
        var impressions_per_day_legend = false;
        var Averarge_page_position_legend = false;
        var avrg_site_ctr = false;
		
        getSiteRelatedDataFunc(records);
        setTimeout(function () {
            setSiteURLFunc(jQuery("#selectedSite option:selected").text());
            if (window.location.href.indexOf("?") > -1) {
                history.pushState("", document.title, window.location.pathname);
            } 
		}, 1000);

        jQuery(document).on("click", "#selectedSiteDetails", function () {
            Inertia.get(jQuery(this).attr("href"), [], {});
            return false;
        });

        jQuery(document).on("keyup", "#searchByURL", function (e) {
            clearTimeout(typingTimer);
            var curElm = jQuery(this);
            var searchByURL = jQuery(curElm).val();

            if (searchByURL.trim() != "" && searchStatus) {
                typingTimer = setTimeout(function () {
                    if (ajaxStatus == 1) {
                        ajaxStatus = 0;
                        doneTyping(curElm, baseURL);
                    }
                }, doneTypingInterval);
            }
        });

        jQuery(document).on("click", "li.result-data-listing", function () {
            jQuery("#searchByURL").val(jQuery(this).text());
            jQuery(".search-sites-results").slideUp();
            var siteURL = jQuery("#searchByURL").val();
            jQuery("#error-messages").css("display", "none");
            jQuery("#ajax-loading").css("display", "flex");
            const postData = reactive({
                site: siteURL,
                _token: usePage().props.value.csrf_token
            });

            jQuery(".chart-warpper").css("opacity", 1);
            function  filterhelper(postData){
              Inertia.post(route("getResultByInsertedSiteURL"), postData, {
                onSuccess: (response) => {

                    var siteData = response.props.siteData;
                    if (siteData.length > 0) {
                        setSiteURLFunc(siteURL);
                        getSiteRelatedDataFunc(response.props.siteData, 1);
                    } else {
                        jQuery(".chart-warpper").css("opacity", 0);
                        jQuery("#error-messages strong").html(
                            "No Data Found Against Given URL (" + siteURL + ")"
                        );
                        jQuery("#error-messages").css("display", "block");
                    }
                    jQuery("#ajax-loading").css("display", "none");
                },
                onError: (errors) => {
                    jQuery("#error-messages strong").html(errors);
                    jQuery("#error-messages").css("display", "block");
                },
            });

        }
        filterhelper(postData)
			return false;
        });

        function doneTyping(curElm, ajaxURL) {
            if (jQuery(curElm).val() != "") {
                searchStatus = 0;
				jQuery(".searching_list").html("Searching Please Wait ....");
				
                var data = {
                    searchSite: jQuery(curElm).val(),
                    _token: usePage().props.value.csrf_token,
                };

                jQuery.post(
                    ajaxURL + "/get-sites-list",
                    data,
                    function (response) {
                        if (response) {
                            jQuery(".searching_list").html("");

                            var resultHtml = "";
                            ajaxStatus = searchStatus = 1;
                            var resultData = $.parseJSON(response);
                            jQuery(".search-sites-results").slideUp();
                            jQuery(".search-sites-results").html("");

                            resultHtml +=
                                '<ul class="result-data-warpper card-body">';
                            if (typeof resultData !== "undefined") {
                                if (
                                    typeof resultData.length !== "undefined" &&
                                    resultData.length == 0
                                ) {
                                    resultHtml +=
                                        '<li style="text-align:center;"><strong>No Result Found!</strong></li>';
                                } else {
                                    for (const [key, value] of Object.entries(
                                        resultData
                                    )) {
                                        resultHtml +=
                                            '<li class="result-data-listing">' +
                                            value +
                                            "</li>";
                                    }
                                }
                            } else {
                                resultHtml +=
                                    '<li style="text-align:center;"><strong>No Result Found!</strong></li>';
                            }
                            resultHtml += "</ul>";

                            jQuery(".search-sites-results").append(resultHtml);
                            jQuery(".search-sites-results").slideDown();
                        }
                    }
                );
            }
        }

        function setSiteURLFunc(siteURL) {
            jQuery("#selectedSiteURL").html("<a id='selectedSiteDetails' href='"+baseURL+"/details/"+btoa(siteURL)+"'>("+siteURL+")</a>");
        }

        function getSiteRelatedDataFunc(records, isUpdate = 0) {
            jQuery("#filter").css("display", "block");
            var totalRecords = records.length;
            if (totalRecords) {
                for (var counter = 0; counter < totalRecords; counter++) {
                    years[counter] = records[counter].date;
                    clicks[counter] = records[counter].clicks;
                    impressions[counter] = records[counter].impressions;
                    ctrs[counter] = records[counter].ctr;
                    positions[counter] = records[counter].position;
                }

                analyticsChart = {
                    type: "line",
                    data: {
                        labels: years,
                        datasets: [
                            {
                                label: "Clicks Per Day",
                                yAxisID: 'Clicks Per Day',
                                type: "line",
                                data: clicks,
                                backgroundColor: "transparent",
                                borderColor: "#007bff",
                                pointBorderColor: "#007bff",
                                pointBackgroundColor: "#007bff",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },
                            {
                                label: "Impressions Per Day",
                                type: "line",
                                data: impressions,
                                backgroundColor: "transparent",
                                borderColor: "#6610f2",
                                pointBorderColor: "#6610f2",
                                pointBackgroundColor: "#6610f2",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },
                            {
                                label: "Average Page Position",
                                type: "line",
                                data: positions,
                                backgroundColor: "transparent",
                                borderColor: "#309f6c",
                                pointBorderColor: "#309f6c",
                                pointBackgroundColor: "#309f6c",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },
                            {
                                label: "Average Site CTR",
                                type: "line",
                                data: ctrs,
                                backgroundColor: "transparent",
                                borderColor: "#cb880f",
                                pointBorderColor: "#cb880f",
                                pointBackgroundColor: "#cb880f",
                                fill: false,
                                pointRadius: 0,
                                tension: 0.5,
                            },
                        ],
                    },
                    options: {


                        scales: {

                                      yAxis: {
                                      id:  'Clicks Per Day',
                                      type: 'linear',
                                      position: 'right',      
                                             }, 
          
                                 },


                        responsive: false,
                        maintainAspectRatio: false,
                        interaction: {
                            intersect: false,
                        },
                        hover: {
                            mode: mode,
                            intersect: intersect,
                        },
                        plugins: {
                            legend: {
                                display: false,
                            },
                            tooltips: {
                                mode: mode,
                                intersect: intersect,
                            },
                        },
                    },
                };

                if (isUpdate == 1) {
                    analyticsChartRef.value.update();
                }
            }
        }

        const beforeRenderLogic = (event) => {};

        return {
            user,
            records,
            analyticsChart,
            analyticsChartRef,
            beforeRenderLogic,
            click_per_day_legend,
            impressions_per_day_legend,
            Averarge_page_position_legend,
            avrg_site_ctr,
        };
    },
    methods: {
        Tooglevalue(e) {
            if (e == 0) {
                this.click_per_day_legend = !this.click_per_day_legend;
                this.analyticsChart.data.datasets[e].hidden = this.click_per_day_legend;
            }
            if (e == 1) {
                this.impressions_per_day_legend = !this.impressions_per_day_legend;
                this.analyticsChart.data.datasets[e].hidden = this.impressions_per_day_legend;
            }
            if (e == 2) {
                this.Averarge_page_position_legend = !this.Averarge_page_position_legend;
                this.analyticsChart.data.datasets[e].hidden = this.Averarge_page_position_legend;
            }
            if (e == 3) {
                this.avrg_site_ctr = !this.avrg_site_ctr;
                this.analyticsChart.data.datasets[e].hidden = this.avrg_site_ctr;
            }

            this.analyticsChartRef.update();
        },
        numberFormater(num) {
            return Math.abs(num) > 999
                ? Math.sign(num) * (Math.abs(num) / 1000).toFixed(1) + "k"
                : Math.sign(num) * Math.abs(num);
        },
        useFilterhelper(){
                 jQuery("#ajax-loading").css("display", "block");
                var filterByDays = jQuery("input[name='filterByDays']:checked").attr('id');
                var startDate, endDate;
                if (filterByDays == "customRange") {
                    var startDate = jQuery("#customDateRange")
                        .data("daterangepicker")
                        .startDate.format("YYYY-MM-DD");
                    var endDate = jQuery("#customDateRange")
                        .data("daterangepicker")
                        .endDate.format("YYYY-MM-DD");
                }
                var siteURL = jQuery("#searchByURL").val();
                const postData = reactive({
                    site: siteURL,
                    _token: usePage().props.value.csrf_token,
                    filterByDays:filterByDays,
                    startDate: startDate,
                    endDate: endDate,
                });
                 this.$inertia.post(route("getResultByInsertedSiteURL"), postData, {
                    onSuccess: (response) => {
                     var totalRecords = response.props.siteData.length;
                     var years=[];
                     var clicks=[];
                     var impressions=[];
                     var ctrs=[];
                     var positions=[];
                if (totalRecords>0) {
                for (var counter = 0; counter < totalRecords; counter++) {
                    clicks[counter] = response.props.siteData[counter].clicks;
                    impressions[counter] = response.props.siteData[counter].impressions;
                    ctrs[counter] = response.props.siteData[counter].ctr;
                    positions[counter] = response.props.siteData[counter].position;
                }
                this.analyticsChart.data.labels=response.props.years;
                this.analyticsChart.data.datasets[0].data = clicks;
                this.analyticsChart.data.datasets[1].data = impressions;
                this.analyticsChart.data.datasets[2].data = ctrs;
                this.analyticsChart.data.datasets[3].data = positions;

                    this.analyticsChartRef.update();

            }else{
                this.analyticsChart.data.labels=response.props.years;
                this.analyticsChart.data.datasets[0].data = [0];
                this.analyticsChart.data.datasets[1].data = [0];
                this.analyticsChart.data.datasets[2].data = [0];
                this.analyticsChart.data.datasets[3].data = [0];
                    this.analyticsChartRef.update();
            }
                    jQuery("#ajax-loading").css("display", "none");

                    },
                    onError: (errors) => {
                    },
                });
        }

    },
};
</script>

<style scoped>
#error-messages {
  display: none;
}
.chart-warpper {
  opacity: 0;
}
canvas {
  min-height: 200px;
  min-width: 100%;
}
.mainbox {
  display: flex;
}
#ajax-loading {
  padding: 30% 40%;
}
.box_1 {
  background: rgb(119, 193, 223);
  padding: 2.6% 2% 0% 2%;
  border-top-left-radius: 25px;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}

.box_2 {
  background: #6610f2;
  padding: 2.6% 2% 0% 2%;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.box_3 {
  background: #309f6c;
  padding: 2.6% 2% 0% 2%;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.box_4 {
  background: #cb880f;
  padding: 2.6% 2% 0% 2%;
  border-top-right-radius: 25px;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.cpd .ipd .apps .ast {
  font-size: 30px !important;
  padding: 0px 6px 0px 6px;
  line-height: 1;
  margin-bottom: 0px;
}
.clicktext {
  color: rgb(119, 193, 223);
}
.Impressionstext {
  color: #6610f2;
}
.Positionstext {
  color: #309f6c;
}
.ctrtext {
  color: #cb880f;
}
#filter {
  display: none;
}

.content-header{
  position: sticky;
  top: 0;
  background-color: #f4f6f9;
  z-index: 1100;
}

.head{
  display: flex;
}
.click{
  width: 50%;
  font-weight: bold;
}
.impression{
  width: 50%;
  text-align: right;
  font-weight: bold;
}

</style>