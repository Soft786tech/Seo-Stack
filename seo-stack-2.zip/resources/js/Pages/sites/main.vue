<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-md-12">
              <div id="loading">
                <span class="textloader">Please Wait...</span>
              </div>

              <div class="">
                <div class="py-3 px-2">
                  <div class="text-right">
                    <div
                      v-if="$page.props.errors.errors"
                      class="text-center alert alert-danger"
                      role="alert"
                    >
                      {{ $page.props.errors.errors }}
                    </div>
                    <div
                      v-if="$page.props.flash.success"
                      class="text-center alert alert-success"
                      role="alert"
                    >
                      {{ $page.props.flash.success }}
                    </div>
                  </div>
                  <h1 class="pb-2">Add Website</h1>

                  <form @submit.prevent="save" method="post">
                    <div class="form-group">
                      <span for="siteUrl"
                        >URl of website you want to add :</span
                      >
                      <input
                        type="text"
                        name="siteUrl"
                        required
                        v-model="data.siteUrl"
                        class="form-control"
                        id="siteUrl"
                        aria-describedby="siteURL"
                      />
                    </div>
                    <div class="form-group">
                      <button type="submit" class="btn btn-primary">
                        Add site
                      </button>
                    </div>
                  </form>
                </div>
              </div>
              <div class="card">
                <p class="p-3 pb-0 border-bottom">
                  <b>optional setting :</b> Filter the data return for all
                  reports for this site
                </p>

                <div class="p-3 pt-2">
                  <div class="form-group">
                    <span for="">country filter </span>
                    <input type="text" class="form-control" />
                  </div>
                  <div class="form-group">
                    <span for="">Dimension </span>
                    <select name="" id="" class="form-control">
                      <option disabled selected>Pleas select a option</option>
                      <option value="Page">Page</option>
                      <option value="Query">Query</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <span for="">filter type </span>
                    <select name="" id="" class="form-control">
                      <option disabled selected>Pleas select a option</option>

                      <option value="contains">contains</option>
                      <option value="equal">equal</option>
                      <option value="notcontains">not contains</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <span for="">filter value </span>
                    <input type="text" class="form-control" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
 import AppHeader from "../../Partials/AppHeader.vue";
 import AppSidebar from "../../Partials/AppSidebar.vue";
    import {  Link } from '@inertiajs/inertia-vue3'

export default {
    name:'main',
    created () {
			document.title = 'SeoStack - sites';
		},
    components:{
        Link,
        AppHeader,
        AppSidebar,
    },
   data: function () {
    return {
        data:{
            siteUrl:'',
        }
    }
    },

methods:{
      save(){
		jQuery('#loading').css('display','block');
		jQuery('.textloader').css('display','block');
			console.log("DATA", this.data);
          this.$inertia.post(route('savewebsite'),this.data, {
              onSuccess: (response) => {
                        jQuery('#loading').css("display", "none");
                        jQuery('.textloader').css("display", "none");
                        console.log(response);
					},
					onError: (errors) => {
                         jQuery('#loading').css("display", "none");
                        jQuery('.textloader').css("display", "none");
                        console.log(errors);
					}

				});

        this.data={}
      }
  }

}
</script>
<style>
#loading {
  display: none;
  background: #584c38;
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 1;
  opacity: 0.3;
}
.textloader {
  display: none;
  width: 100%;
  color: white;
  position: absolute;
  top: 10%;
  font-size: 30px;
  text-align: -webkit-center;
}
</style>
