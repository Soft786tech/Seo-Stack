<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-md-12">
              <div class="card card-primary card-outline card-tabs">
                <div class="card-header p-0 pt-1 border-bottom-0">
                  <ul
                    class="nav nav-tabs"
                    id="custom-tabs-three-tab"
                    role="tablist"
                  >
                    <li class="nav-item">
                      <a
                        class="nav-link active"
                        id="custom-tabs-three-home-tab"
                        data-toggle="pill"
                        href="#custom-tabs-three-home"
                        role="tab"
                        aria-controls="custom-tabs-three-home"
                        aria-selected="false"
                        >Website setting</a
                      >
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        id="custom-tabs-three-profile-tab"
                        data-toggle="pill"
                        href="#custom-tabs-three-profile"
                        role="tab"
                        aria-controls="custom-tabs-three-profile"
                        aria-selected="false"
                        >User managemet</a
                      >
                    </li>
                  </ul>
                </div>
                <div class="card-body">
                  <div class="tab-content" id="custom-tabs-three-tabContent">
                    <div
                      class="tab-pane active"
                      id="custom-tabs-three-home"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-home-tab"
                    >
                      <form @submit.prevent="update" method="post">
                        <div class="form-group">
                          <p>
                            Google console search proper url like :<b
                              >https://www.countryhardwood.com/</b
                            >
                          </p>
                          <span for="siteUrl">Site name:</span>
                          <input
                            type="text"
                            name="siteUrl"
                            v-model="data.siteUrl"
                            class="form-control"
                            id="siteUrl"
                            aria-describedby="siteURL"
                          />
                        </div>
                        <div class="form-group">
                          <span for="permissionLevel">permissionLevel</span>
                          <input
                            type="permissionLevel"
                            name="permissionLevel"
                            v-model="data.permissionLevel"
                            class="form-control"
                            id="permissionLevel"
                          />
                        </div>
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary">
                            update
                          </button>
                          <Link
                            :href="$route('delweb', data.id)"
                            class="btn btn-danger ml-2"
                            >Delete Site</Link
                          >
                        </div>
                      </form>
                    </div>
                    <div
                      class="tab-pane fade"
                      id="custom-tabs-three-profile"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-profile-tab"
                    >
                      .....
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import AppHeader from "../../Partials/AppHeader.vue";
import AppSidebar from "../../Partials/AppSidebar.vue";
import {  Link } from '@inertiajs/inertia-vue3'

export default {
    name:'main',
    created () {
			document.title = 'SeoStack - sites-edit';
		},
    components:{
        Link,
        AppHeader,
        AppSidebar,

    },
    props:{
        commingSite:Object,
    },
    data: function () {
    return {
        data:{
            siteUrl:this.commingSite.siteUrl,
            permissionLevel:this.commingSite.permissionLevel,
            id:this.commingSite.id,
        }
    }
  },
  methods:{
      update(){

this.$inertia.post('updatesite',this.data)
.then(res => {
     console.log(res)
  })
      }
  }



}
</script>
