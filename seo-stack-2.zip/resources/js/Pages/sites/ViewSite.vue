<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-md-12">
              <div class="card card-primary card-outline card-tabs">
                <div class="card-header p-0 pt-1 border-bottom-0">
                  <ul
                    class="nav nav-tabs"
                    id="custom-tabs-three-tab"
                    role="tablist"
                  >
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        id="custom-tabs-three-home-tab"
                        data-toggle="pill"
                        href="#custom-tabs-three-home"
                        role="tab"
                        aria-controls="custom-tabs-three-home"
                        aria-selected="false"
                        >Your setting</a
                      >
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        id="custom-tabs-three-profile-tab"
                        data-toggle="pill"
                        href="#custom-tabs-three-profile"
                        role="tab"
                        aria-controls="custom-tabs-three-profile"
                        aria-selected="false"
                        >User managemet</a
                      >
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link active"
                        id="custom-tabs-three-messages-tab"
                        data-toggle="pill"
                        href="#custom-tabs-three-messages"
                        role="tab"
                        aria-controls="custom-tabs-three-messages"
                        aria-selected="false"
                        >Site management</a
                      >
                    </li>
                  </ul>
                </div>
                <div class="card-body">
                  <div class="tab-content" id="custom-tabs-three-tabContent">
                    <div
                      class="tab-pane fade"
                      id="custom-tabs-three-home"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-home-tab"
                    >
                      .....
                    </div>
                    <div
                      class="tab-pane fade"
                      id="custom-tabs-three-profile"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-profile-tab"
                    >
                      .....
                    </div>
                    <div
                      class="tab-pane active"
                      id="custom-tabs-three-messages"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-messages-tab"
                    >
                      <div v-for="sites in sitescrud" :key="sites.id">
                        <div class="d-flex">
                          <Link
                            :href="'Sites/'+sites.id+'/edit'"
                            class="text-green-700"
                            ><div class="mr-auto p-2 onhover-effect">
                              {{ sites.siteUrl }}
                            </div></Link
                          >
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
 import AppHeader from "../../Partials/AppHeader.vue";
 import AppSidebar from "../../Partials/AppSidebar.vue";
import {  Link } from '@inertiajs/inertia-vue3'

export default {
    name:'main',
    created () {
			document.title = 'SeoStack - sites';
		},
    components:{
        Link,
        AppHeader,
        AppSidebar,
    },
    props:{
        sitescrud: Object,
    },


}
</script>
<style scoped>
.onhover-effect:hover {
  border-bottom: 3px solid red;
  background: gainsboro;
}
.card-header{
  position: sticky;
  top: 0;
  background-color: white;
}
</style>
