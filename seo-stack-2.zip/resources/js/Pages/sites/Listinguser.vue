<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-md-12">
              <div class="card card-primary card-outline card-tabs">
                <div class="card-header p-0 pt-1 border-bottom-0">
                  <ul
                    class="nav nav-tabs"
                    id="custom-tabs-three-tab"
                    role="tablist"
                  >
                 
                    <li class="nav-item">
                      <a
                        class="nav-link active"
                        id="custom-tabs-three-messages-tab"
                        data-toggle="pill"
                        href="#custom-tabs-three-messages"
                        role="tab"
                        aria-controls="custom-tabs-three-messages"
                        aria-selected="false"
                        >Email management</a
                      >
                    </li>
                  </ul>
                </div>
                <div class="card-body">
                  <div class="tab-content" id="custom-tabs-three-tabContent">
                    <div
                      class="tab-pane fade"
                      id="custom-tabs-three-home"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-home-tab"
                    >
                      .....
                    </div>
                    <div
                      class="tab-pane fade"
                      id="custom-tabs-three-profile"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-profile-tab"
                    >
                      .....
                    </div>
                    <div
                      class="tab-pane active"
                      id="custom-tabs-three-messages"
                      role="tabpanel"
                      aria-labelledby="custom-tabs-three-messages-tab"
                    >
                      <div v-for="sitescrud in sitescrud" :key="sitescrud.id" class="d-main">


   
                     

                         <div class="d-flex1">    
                                <Link>{{sitescrud.email}}</Link>
                         </div>

                       
                      
                         <div class="d-flex2" v-if="sitescrud.status == 1">
                                <!-- <Link :href="'confirm/'+sitescrud.id+'/conf'" >{{sitescrud.status}}</Link> -->
                                <a href="javascript:;" v-on:click="deactive(sitescrud.id)">Active</a>
                         </div>
                         <div class="d-flex2" v-else>
                                <!-- <Link :href="'confirm/'+sitescrud.id+'/conf'" >{{sitescrud.status}}</Link> -->
                                <a href="javascript:;" v-on:click="active(sitescrud.id)">Deactive</a>
                         </div>
                       


                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
 import AppHeader from "../../Partials/AppHeader.vue";
 import AppSidebar from "../../Partials/AppSidebar.vue";
 import {  Link, usePage } from '@inertiajs/inertia-vue3'
 import {Inertia} from "@inertiajs/inertia";
export default {
    name:'Listinguser',
    created () {
			document.title = 'SeoStack - sites';
		},
    components:{
        Link,
        AppHeader,
        AppSidebar,
    },
    props:{
        sitescrud: Object,
    },

    

methods: {

 deactive(id) {

   if(confirm("Do you really want to Deactive?")){

               Inertia.get(route('confirm',id));             
    }
 },



active(id) {

   if(confirm("Do you really want to Active?")){

               Inertia.get(route('confirm',id));             
    }
 }

},
   

    

    setup(props) {


  


		
		const sitescrud = usePage().props.value.sitescrud;	
				
        return {
            sitescrud,
			
        }		
	}


}
</script>
<style scoped>
.onhover-effect:hover {
  border-bottom: 3px solid red;
  background: gainsboro;
}
.d-main{
    display: flex;
}
.d-flex1{
    width: 90%;
}
.d-flex2{
    width: 10%;
    text-align: right;
    margin-bottom: 20px;
}

.d-flex2:hover {
  border-bottom: 3px solid red;
  background: gainsboro;
}



</style>
