<template>
  <div class="wrapper">
    <app-header></app-header>
    <app-sidebar></app-sidebar>
    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2" v-if="user">
            <div class="col-sm-4">
              <h1 class="m-0">Projects <span>({{sites.length}})</span></h1>
            </div>
          </div>
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-2 mb-3" v-for="site in sites" :key="site" v-on:click="getSiteDetails(site)">
              <div class="card h-100">
                <div class="card-body">
                  <p class="card-text" v-html="getSiteDomain(site)"></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>

  let mainObj;
  import AppHeader from "../Partials/AppHeader";
  import AppSidebar from "../Partials/AppSidebar";
  import ErrorsAndMessages from "../Partials/ErrorsAndMessages";
  import Vue3ChartJs from "@j-t-mcc/vue3-chartjs";
  import { Inertia } from "@inertiajs/inertia";
  import { computed } from "vue";
  import { ref } from "vue";
  import { usePage, Link } from "@inertiajs/inertia-vue3";
  import { reactive, inject } from "vue";

export default {
  name: "Project",
  created() {
    mainObj = this;
    document.title = "SeoStack - Project";
  },
  components: {
    Link,
    ErrorsAndMessages,
    AppHeader,
    AppSidebar,
    },
    props: {
      errors: Object,
      startDate:Object,
      endDate:Object
    },
    data() {
      return {
        keywordDetails: [],
      }
    },
    setup() {
      const user = computed(() => usePage().props.value.auth.user);
      const sites = computed(() => usePage().props.value.sites);

      return {
          user,
          sites
      }
    },
    methods: {
      getSiteDomain(url)
      {
        var url = url;
        var domain = url.replace('http://','').replace('https://','').split(/[/?#]/)[0];
        var sitName = "<b>"+domain+"</b>";
        return sitName;
      },
      getSiteDetails(url)
      {
        const postData = reactive({
          site: url,
          _token: usePage().props.value.csrf_token,
        });
        console.log(url);
        // Inertia.post(route("showSingleSiteDetailsProject"), postData, {
        //   onSuccess: (response) => {
        //     this.keywordDetails = response.props.keywordDetails;
        //   },
        //   onError: (errors) => {
        //     alert("errors");
        //   },
        // });
      },
      // async getMetatagValue(urlss)
      // {
      //    $.ajax({
      //         url: "http://textance.herokuapp.com/title/"+urlss,
      //         complete: function(data) {
      //         var Title = "<b>"+data.responseText+"</b>";
      //           console.log(Title);
      //         }
      //   });
      // }
    }
};

</script>

<style scoped>
canvas {
  min-height: 200px;
  min-width: 100%;
}
.box_1 {
  background: rgb(119, 193, 223);
  padding: 2.6% 2% 0% 2%;
  border-top-left-radius: 25px;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}

.box_2 {
  background: #6610f2;
  padding: 2.6% 2% 0% 2%;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.box_3 {
  background: #309f6c;
  padding: 2.6% 2% 0% 2%;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.box_4 {
  background: #cb880f;
  padding: 2.6% 2% 0% 2%;
  border-top-right-radius: 25px;
  color: white;
  font-size: 1vw;
  cursor: pointer;
}
.cpd .ipd .apps .ast {
  font-size: 30px !important;
  padding: 0px 6px 0px 6px;
  line-height: 1;
  margin-bottom: 0px;
}
.clicktext {
  color: rgb(119, 193, 223);
}
.Impressionstext {
  color: #6610f2;
}
.Positionstext {
  color: #309f6c;
}
.ctrtext {
  color: #cb880f;
}
.content-header{
  background:#f4f6f9 ;
  position: sticky;
  top: 0;
  z-index: 1100;
}
.head{
  display: flex;
}
.click{
  width: 50%;
  font-weight: bold;
}
.impression{
  width: 50%;
  text-align: right;
  font-weight: bold;
}
.card{
  border-radius: 4px;
  background: #fff;
  box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);
  transition: .3s transform cubic-bezier(.155,1.105,.295,1.12),.3s box-shadow,.3s -webkit-transform cubic-bezier(.155,1.105,.295,1.12);
  cursor: pointer;
}
.card:hover{
 transform: scale(1.05);
 box-shadow: 0 10px 20px rgba(0,0,0,.12), 0 4px 8px rgba(0,0,0,.06);
}

.card p{
  font-weight: 600;
}


</style>