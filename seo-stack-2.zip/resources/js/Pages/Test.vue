<template>
    <p>THIS IS A TEST</p>
</template>

<script>
  export default {
    mounted: function() {
      console.log('Mounted');
    }
  }
</script>
