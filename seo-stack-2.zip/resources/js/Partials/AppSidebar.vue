<template>
	<aside class="main-sidebar sidebar-dark-primary elevation-4">
		<Link :href="$route('showDashboardForm')" class="nav-link logout-link" id="dashboard-link">
			<span class="brand-text font-weight-bold">SeoStack</span>
		</Link>

		<div class="sidebar">
			<div v-if="sites.length > 0 && user">
				<select class="select2" id="selectedSite" name="selectedSite">
					<option v-for="site in sites" :key="site">{{site}}</option>
				</select>
				
			</div>
			<nav class="mt-2">
				<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false"  v-if="user">
					<li class="nav-item menu-open">
						<Link :href="$route('showDashboardForm')" as="button" class="nav-link" type="button">Dashboard</Link>
					</li>
					<li class="nav-item">
						<Link :href="$route('showPorject')" as="button" class="nav-link" type="button">Dashboard New</Link>
					</li>
					
					<li class="nav-item">
                    <a href="#" class="nav-link">
                    <p>
                    Tools
                    <i class="fas fa-angle-left right"></i>
                    </p>
                    </a>
                    <ul class="nav nav-treeview" style="display: none;">
	                    <li class="nav-item">
	                   	<!-- <Link :href="$route('showReports')" as="button" class="nav-link" type="button">Query Test</Link> -->
	                    </li>  
	                    <li class="nav-item">
	                   	<Link :href="$route('showQuery')" as="button" class="nav-link" type="button">Query Row Count Tool</Link>
	                    </li>            
                    </ul>
                    </li>
                    <li class="nav-item">
                   		<Link :href="$route('userlisting')" as="button" class="nav-link" type="button">User Listing</Link>
                    </li>

                    <li class="nav-item">
						<a href="#" class="nav-link">
							<p>Google Search Console<i class="fas fa-angle-left right"></i></p>
						</a>
						<ul class="nav nav-treeview" style="display: none;">
							<li class="nav-item">
								<Link :href="$route('googleSearchConsoleOAuth')" as="button" class="nav-link" type="button">Upload OAuth JSON</Link>
							</li>
						</ul>
                    </li>

					<li class="nav-item ">
						<Link :href="$route('getResultByInsertedSiteURL')" as="button" class="nav-link" type="button">Result By URL</Link>
					</li>
                    <li class="nav-item">
                    <a href="#" class="nav-link">
                    <p>
                    Sites
                    <i class="fas fa-angle-left right"></i>
                    </p>
                    </a>
                    <ul class="nav nav-treeview" style="display: none;">
                    <li class="nav-item">
                   	<Link :href="$route('addsite')" as="button" class="nav-link" type="button">Add site</Link>

                    </li>
                    <li class="nav-item">
                   		<Link :href="$route('viewsites')" as="button" class="nav-link" type="button">view site</Link>

                    </li>


                    </ul>
                    </li>

					<li class="nav-item ">
						<Link :href="$route('logout')" as="button" method="post" class="nav-link logout-link" type="button">Logout</Link>
					</li>
				</ul>
				<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false" v-if="!user">
					<li class="nav-item ">
						<Link :href="$route('showLoginForm')" class="nav-link">Login</Link>
					</li>
				</ul>
			</nav>
		</div>
	</aside>
</template>

<script>
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";

export default {
    components: {
        Link
    },
	created () {
    },
    name: "AppSidebar",
    setup() {

        const user = computed(() => usePage().props.value.auth.user);
		const sites = computed(() => usePage().props.value.sites);
       

        
		setTimeout(function(){
			jQuery('.select2').select2()
		}, 1000);

        return {
            user,
			sites
        }
    }
}
</script>
<style scoped>
	#dashboard-link {
		text-align: center;
		font-size: 30px;
		font-weight: bold;
		color: #fff;
	}
	button.nav-link{
		border: 0px;
		background: none;
		padding: 15px 10px;
		display: block;
		width: 100%;
		text-align: left;
	}
	#selectedSite{
     width: 370px;
	}
</style>
