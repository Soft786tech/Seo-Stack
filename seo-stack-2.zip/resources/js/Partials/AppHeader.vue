<template>

	<nav
    class="main-header navbar navbar-expand navbar-white navbar-light styleA ">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
			</li>
		</ul>
	</nav>
</template>

<script>
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";

export default {
    components: {
        Link
    },

    name: "AppHeader",
    setup() {
        const user = computed(() => usePage().props.value.user);
   
        return {
            user
        }
    }
}
</script>
<style >
.styleA{
    margin-top:1.7px!important;
}
h3,h1,h2,h4,h5,h6,div,p,span,ul,li {
   font-family: 'Quicksand', sans-serif;

    }

</style>
