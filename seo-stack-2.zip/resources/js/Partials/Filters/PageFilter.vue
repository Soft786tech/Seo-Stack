<template>
	<div id="pageFilter" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header bg-dark">
					<h4 class="modal-title">Page</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class="custom-control custom-radio pb-3 pl-0">
							<ul class="navbar-nav">
								<a class="nav-link selected-page-filter" data-toggle="dropdown" href="#" aria-expanded="false" rel="urlsContaining">URLs containing</a>
								<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="left: inherit; right: 0px;">
									<a href="#" class="dropdown-item select-page-filter" rel="urlsContaining">URLs containing</a>
									<a href="#" class="dropdown-item select-page-filter" rel="urlsNotContaining">URLs not containing</a>
									<a href="#" class="dropdown-item select-page-filter" rel="exactUrl">Exact url</a>
								</div>
							</ul>
							<input class="form-control" type="text" id="url" name="url" />
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-default" id="applyURLFilter">Apply</button>
				</div>							
			</div>
		</div>
	</div>
</template>

<script>
import { Inertia } from "@inertiajs/inertia";
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";

export default {
    components: {
        Link
    },
	created () {
    },
    name: "PageFilter",
    setup() {
        const user = computed(() => usePage().props.value.auth.user);
		const getData = usePage().props.value.getData;
		var baseURL = jQuery("#baseURL").val();
		var currentLocation = window.location.href;		
		
		setTimeout(function () {
			jQuery(document).on("click", "#applyURLFilter", function () {
				var url = jQuery("#url").val();				
				url = url.trim();
				var requestURL = jQuery("#selectedSite option:selected").text()
				jQuery("#toast-container").remove();
				
				if(url != ""){
					jQuery("#ajax-loading").css("display", "flex");
					var data = {
						url: requestURL,
						site: url,
						siteURL: btoa(url),
						pageFilter: jQuery(".selected-page-filter").attr("rel"),
						keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
						queryFilter: ((typeof getData['queryFilter'] !== "undefined") ? getData['queryFilter'] : ""),						
						country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),						
						filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),	
						startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),		
						endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),						
					};
					
					jQuery("#pageFilter button.close").trigger("click");
					var requestURL = baseURL+"/dashboard";
					
					if(currentLocation.indexOf("/details/") >= 0){
						requestURL = baseURL+"/details/"+btoa(url);
					}				
					else if(currentLocation.indexOf("/search-by-url") >= 0){
						requestURL = baseURL+"/search-by-url";
					}	
					
					Inertia.get(requestURL, data, {});			
				}
				else{
					jQuery("body").append('<div id="toast-container" class="toast-top-right"><div class="toast toast-error" aria-live="assertive" style=""><div class="toast-message">Please provide url to search!</div></div></div>');
					
					setTimeout(function(){
						jQuery("#toast-container").hide(3000);
					}, 5000);
				}
			});

		   jQuery(document).on("click", ".select-page-filter", function (){
				jQuery(".selected-page-filter").text(jQuery(this).text());
				jQuery(".selected-page-filter").attr("rel", jQuery(this).attr("rel"));
				jQuery(this).parents("div.dropdown-menu").removeClass("show");
				jQuery(this).parents("ul.navbar-nav").removeClass("show");
				return false;
			});
			
			jQuery(document).on("click", "#selectedSiteDetails", function () {
				Inertia.get(jQuery(this).attr("href"), [], {});
				return false;
			});			
			
			if(
				typeof getData['url'] !== "undefined" &&
				typeof getData['pageFilter'] !== "undefined" &&
				getData['url'] != null &&				
				getData['pageFilter'] != null		
			){
				var appliedFilter = '';
				appliedFilter += '<div class="card card-warning shadow">';
					appliedFilter += '<div class="card-header" style="background-color: #23272b;border-radius: 4px;font-size: 15px;padding: 8.7px 10px;color:#fff;">';
						appliedFilter += '<h3 class="card-title" style="font-size: 15px;">Page: '+getData['url']+'</h3>';
						appliedFilter += '<div class="card-tools">';
							appliedFilter += '<button type="button" class="btn btn-tool" id="removePageFilter" data-card-widget="remove" style="color: #fff;"><i class="fas fa-times"></i></button>';
						appliedFilter += '</div>';
					appliedFilter += '</div>';
				appliedFilter += '</div>';				
				
				jQuery(".extra-filters").before('<div class="col-sm-12 col-lg-3">'+appliedFilter+'</div>');
			}			
			
			jQuery(document).on("click", "#removePageFilter", function (){
				var requestedSite = ((typeof getData['url'] !== "url") ? getData['url'] : "");
				jQuery("#ajax-loading").css("display", "flex");
				var data = {
					url: requestedSite,
					siteURL: btoa(requestedSite),
					keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
					queryFilter: jQuery(".selected-query-filter").attr("rel"),
					country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),			
					filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),	
					startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
					endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),	
				};
				
				jQuery("#queryFilter button.close").trigger("click");
				
				var requestURL = baseURL+"/dashboard";
				
				if(currentLocation.indexOf("/details/") >= 0){
					requestURL = baseURL+"/details/"+btoa(requestedSite);
				}				
				else if(currentLocation.indexOf("/search-by-url") >= 0){
					requestURL = baseURL+"/search-by-url";
				}					
				
				Inertia.get(requestURL, data, {});		
			});
			
		}, 1000); 
		
        return {
            user
        }
    }
}
</script>