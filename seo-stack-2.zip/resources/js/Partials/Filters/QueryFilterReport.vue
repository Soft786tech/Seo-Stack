<template>
	<div id="queryFilter" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header bg-dark">
					<h4 class="modal-title">Query</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class="custom-control custom-radio pb-3 pl-0">
							<ul class="navbar-nav">
								<a class="nav-link selected-query-filter" data-toggle="dropdown" href="#" aria-expanded="false" rel="queriesContaining">Queries containing</a>
								<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="left: inherit; right: 0px;">
									<a href="#" class="dropdown-item select-query-filter" rel="queriesContaining">Queries containing</a>
									<a href="#" class="dropdown-item select-query-filter" rel="queriesNotContaining">Queries not containing</a>
									<a href="#" class="dropdown-item select-query-filter" rel="exactQuery">Exact query</a>
								</div>
							</ul>
							<input class="form-control" type="text" id="keyword" name="keyword" />
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-default" id="applyQueryFilter">Apply</button>
				</div>							
			</div>
		</div>
	</div>
</template>

<script>
import { Inertia } from "@inertiajs/inertia";
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";

export default {
    components: {
        Link
    },
	created () {
    },
    name: "QueryFilterReport",
    setup() {
        const user = computed(() => usePage().props.value.auth.user);
		const getData = usePage().props.value.getData;
		var baseURL = jQuery("#baseURL").val();
		var currentLocation = window.location.href;
		
		setTimeout(function () {
			jQuery(document).on("click", "#applyQueryFilter", function () {
				var keyword = jQuery("#keyword").val();
				var requestedSite = (jQuery("input[type='search']#searchByURL").length > 0) ? jQuery("input[type='search']#searchByURL").val() : jQuery("#selectedSite option:selected").text();
				jQuery("#toast-container").remove();
				
				if(keyword.trim() != ""){
					jQuery("#ajax-loading").css("display", "flex");
					var data = {
						keyword: keyword.trim(),
						queryFilter: jQuery(".selected-query-filter").attr("rel"),
						url: '',
						site: '',
						siteURL: '',
						pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),
						country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),			
						filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),	
						startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
						endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),	
					};
					
					var requestURL = baseURL+"/report";
					
					if(currentLocation.indexOf("/details/") >= 0){
						requestURL = baseURL+"/details/"+btoa(requestedSite);
					}
					else if(currentLocation.indexOf("/search-by-url") >= 0){
						requestURL = baseURL+"/search-by-url";
					}					
					
					jQuery("#queryFilter button.close").trigger("click");
					Inertia.get(requestURL, data, {});			
				}
				else{
					jQuery("body").append('<div id="toast-container" class="toast-top-right"><div class="toast toast-error" aria-live="assertive" style=""><div class="toast-message">Please provide keyword to search!</div></div></div>');
					
					setTimeout(function(){
						jQuery("#toast-container").hide(3000);
					}, 5000);
				}
			});

		   jQuery(document).on("click", ".select-query-filter", function (){
				jQuery(".selected-query-filter").text(jQuery(this).text());
				jQuery(".selected-query-filter").attr("rel", jQuery(this).attr("rel"));
				jQuery(this).parents("div.dropdown-menu").removeClass("show");
				jQuery(this).parents("ul.navbar-nav").removeClass("show");
				return false;
			});
			
			jQuery(document).on("click", "#selectedSiteDetails", function () {
				Inertia.get(jQuery(this).attr("href"), [], {});
				return false;
			});			
			
			if(
				typeof getData['keyword'] !== "undefined" &&
				typeof getData['queryFilter'] !== "undefined" &&
				getData['keyword'] != null
			){
				var appliedFilter = '';
				appliedFilter += '<div class="card card-warning shadow">';
					appliedFilter += '<div class="card-header" style="background-color: #23272b;border-radius: 4px;font-size: 15px;padding: 8.7px 10px;color:#fff;">';
						appliedFilter += '<h3 class="card-title" style="font-size: 15px;">Query: '+getData['keyword']+'</h3>';
						appliedFilter += '<div class="card-tools">';
							appliedFilter += '<button type="button" class="btn btn-tool" id="removeQueryFilter" data-card-widget="remove" style="color: #fff;"><i class="fas fa-times"></i></button>';
						appliedFilter += '</div>';
					appliedFilter += '</div>';
				appliedFilter += '</div>';				
				
				jQuery(".extra-filters").before('<div class="col-sm-12 col-lg-3">'+appliedFilter+'</div>');
				setSiteURLForSearchByUrlFunc(getData['url']);
				jQuery(".card.chart-warpper").css("opacity", 1);
				jQuery("#filter").css("display", "block");				
			}			
			
			jQuery(document).on("click", "#removeQueryFilter", function (){
				var requestedSite = ((typeof getData['url'] !== "url") ? getData['url'] : "");
				jQuery("#ajax-loading").css("display", "flex");
				var data = {
					url: requestedSite,
					siteURL: btoa(requestedSite),
					pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),
					country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),			
					filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),	
					startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
					endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),	
				};
				
				jQuery("#queryFilter button.close").trigger("click");
				
				var requestURL = baseURL+"/report";
				
				if(currentLocation.indexOf("/details/") >= 0){
					requestURL = baseURL+"/details/"+btoa(requestedSite);
				}				
				else if(currentLocation.indexOf("/search-by-url") >= 0){
					requestURL = baseURL+"/search-by-url";
				}					
				
				Inertia.get(requestURL, data, {});		
			});
			
		}, 1000); 
		
        function setSiteURLForSearchByUrlFunc(siteURL) {
            jQuery("#selectedSiteURL").html("<a id='selectedSiteDetails' href='"+baseURL+"/details/"+btoa(siteURL)+"'>("+siteURL+")</a>");
			if(jQuery("input[type='search']#searchByURL").length > 0) jQuery("input[type='search']#searchByURL").val(siteURL);
        }	
		
        return {
            user
        }
    }
}
</script>