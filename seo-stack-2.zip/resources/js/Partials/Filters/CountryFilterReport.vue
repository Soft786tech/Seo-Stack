<template>
	<div id="countriesFilter" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header bg-dark">
					<h4 class="modal-title">Country</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body filter-countries">
					<div class="form-group">
						<div class="custom-control custom-radio pb-3" v-for="country in countries">
							<input class="custom-control-input" type="radio" :id="country.iso_code" name="filterByCountry" />
							<label :for="country.iso_code" class="custom-control-label">{{country.name}}</label>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-default" data-dismiss="modal" id="applyCountryFilter">Apply</button>
				</div>
			</div>
		</div>
	</div>
</template>	
<script>
import { Inertia } from "@inertiajs/inertia";
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";

export default {
    components: {
        Link
    },
	created () {
    },
    name: "CountryFilterReport",
    setup() {
        const user = computed(() => usePage().props.value.auth.user);
        const countries = computed(() => usePage().props.value.countries);
		const getData = usePage().props.value.getData;
		var baseURL = jQuery("#baseURL").val();
		var currentLocation = window.location.href;		
		
		setTimeout(function () {
			jQuery(document).on("click", "#applyCountryFilter", function () {
				var country = jQuery("input[name='filterByCountry']:checked").attr("id");
				var requestedSite = (jQuery("input[type='search']#searchByURL").length > 0) ? jQuery("input[type='search']#searchByURL").val() : jQuery("#selectedSite option:selected").text();
				
				jQuery("#toast-container").remove();
				
				if(country.trim() != ""){
					jQuery("#ajax-loading").css("display", "flex");
					var data = {
						country: country.trim(),
						keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
						queryFilter: ((typeof getData['queryFilter'] !== "undefined") ? getData['queryFilter'] : ""),			
						url: '',
						site: '',
						siteURL: '',						
						pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),						
						filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),	
						startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
						endDate: ((typeof getData['endDate'] !== "undefined") ? getData['endDate'] : ""),							
					};
					
					jQuery("#countriesFilter button.close").trigger("click");
					var requestURL = baseURL+"/report";
					
					if(currentLocation.indexOf("/details/") >= 0){
						requestURL = baseURL+"/details/"+btoa(requestedSite);
					}		
					else if(currentLocation.indexOf("/search-by-url") >= 0){
						requestURL = baseURL+"/search-by-url";
					}		
					
					Inertia.get(requestURL, data, {});			
				}
				else{
					jQuery("body").append('<div id="toast-container" class="toast-top-right"><div class="toast toast-error" aria-live="assertive" style=""><div class="toast-message">Please select country to search!</div></div></div>');
					
					setTimeout(function(){
						jQuery("#toast-container").hide(3000);
					}, 5000);
				}
			});    
			
			if(
				typeof getData['country'] !== "undefined" &&
				getData['country'] != null &&
				getData['country'] != ""
			){
				var appliedFilter = '';
				appliedFilter += '<div class="card card-warning shadow">';
					appliedFilter += '<div class="card-header" style="background-color: #23272b;border-radius: 4px;font-size: 15px;padding: 8.7px 10px;color:#fff;">';
						appliedFilter += '<h3 class="card-title" style="font-size: 15px;">Country: '+jQuery('label[for="'+getData['country']+'"]').text()+'</h3>';
						appliedFilter += '<div class="card-tools">';
							appliedFilter += '<button type="button" class="btn btn-tool" id="removeCountryFilter" data-card-widget="remove" style="color: #fff;"><i class="fas fa-times"></i></button>';
						appliedFilter += '</div>';
					appliedFilter += '</div>';
				appliedFilter += '</div>';				
				
				jQuery(".extra-filters").before('<div class="col-sm-12 col-lg-3">'+appliedFilter+'</div>');
				setSiteURLForSearchByUrlFunc(getData['url']);
				jQuery(".card.chart-warpper").css("opacity", 1);
				jQuery("#filter").css("display", "block");						
			}        	
			
			jQuery(document).on("click", "#removeCountryFilter", function (){
				var requestedSite = ((typeof getData['url'] !== "url") ? getData['url'] : "");
				jQuery("#ajax-loading").css("display", "flex");
				var data = {
					url: requestedSite,
					pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),
					keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
					queryFilter: jQuery(".selected-query-filter").attr("rel"),
					filterByDays: ((typeof getData['filterByDays'] !== "undefined") ? getData['filterByDays'] : ""),	
					startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
					startDate: ((typeof getData['startDate'] !== "undefined") ? getData['startDate'] : ""),	
				};
				
				jQuery("#queryFilter button.close").trigger("click");
				var requestURL = baseURL+"/report";
				
				if(currentLocation.indexOf("/details/") >= 0){
					requestURL = baseURL+"/details/"+btoa(requestedSite);
				}			
				else if(currentLocation.indexOf("/search-by-url") >= 0){
					requestURL = baseURL+"/search-by-url";
				}		
					
				Inertia.get(requestURL, data, {});		
			});			
		}, 1000); 
		
        function setSiteURLForSearchByUrlFunc(siteURL) {
            jQuery("#selectedSiteURL").html("<a id='selectedSiteDetails' href='"+baseURL+"/details/"+btoa(siteURL)+"'>("+siteURL+")</a>");
			if(jQuery("input[type='search']#searchByURL").length > 0) jQuery("input[type='search']#searchByURL").val(siteURL);
        }	
		
        return {
            user,
			countries
        }
    }
}
</script>
<style scoped>
.filter-countries{
	height: 200px;
	overflow-y:scroll;
}
</style>