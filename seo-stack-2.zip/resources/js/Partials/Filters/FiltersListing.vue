<template>
	<div class="row">
		<div class="col-sm-12 col-lg-3">
			<button type="button" class="btn btn-block btn-dark btn-lg" data-toggle="modal" data-target="#dateRangeFilter">Filter By Date</button>
		</div>
		<div class="col-sm-12 col-lg-3 extra-filters">
			<ul class="navbar-nav">
				<li class="nav-item dropdown">
					<a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false">+ New</a>		
					<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="left: inherit; right: 0px;">
						<a href="#" data-toggle="modal" data-target="#queryFilter" class="dropdown-item">
							Query...
							<div class="dropdown-divider"></div>
						</a>
						<a href="#" data-toggle="modal" data-target="#pageFilter" class="dropdown-item">
							Page...
							<div class="dropdown-divider"></div>
						</a>
						<a href="#" data-toggle="modal" data-target="#countriesFilter" class="dropdown-item">
							Country...
							<div class="dropdown-divider"></div>                            
						</a>
					</div>						
				</li>
			</ul>
		</div>
	</div>
</template>	
<script>
import { Inertia } from "@inertiajs/inertia";
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";

export default {
    components: {
        Link
    },
	created () {
    },
    name: "FiltersListing",
    setup() {
        const user = computed(() => usePage().props.value.auth.user);
		
        return {
            user
        }
    }
}
</script>
<style scoped>
.filter-warpper button{
	font-size:15px;
}
</style>