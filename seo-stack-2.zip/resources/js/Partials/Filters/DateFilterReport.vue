<template>
	<div id="dateRangeFilter" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header bg-dark">
					<h4 class="modal-title">Date range</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class="custom-control custom-radio pb-3">
							<input class="custom-control-input" type="radio" id="last7Days" name="filterByDays" />
							<label for="last7Days" class="custom-control-label">Last 7 days</label>
						</div>
						<div class="custom-control custom-radio pb-3">
							<input class="custom-control-input" type="radio" id="last28Days" name="filterByDays" />
							<label for="last28Days" class="custom-control-label">Last 28 days</label>
						</div>
						<div class="custom-control custom-radio pb-3">
							<input class="custom-control-input" type="radio" id="last3Months" name="filterByDays" />
							<label for="last3Months" class="custom-control-label">Last 3 Months</label>
						</div>
						<div class="custom-control custom-radio pb-3">
							<input class="custom-control-input" type="radio" id="last6Months" name="filterByDays" />
							<label for="last6Months" class="custom-control-label">Last 6 Months</label>
						</div>
						<div class="custom-control custom-radio pb-3">
							<input class="custom-control-input" type="radio" id="last12Months" name="filterByDays"/>
							<label for="last12Months" class="custom-control-label">Last 12 Months</label>
						</div>
						<div class="custom-control custom-radio pb-3">
							<input class="custom-control-input" type="radio" id="last16Months" name="filterByDays"/>
							<label for="last16Months" class="custom-control-label">Last 16 Months</label>
						</div>
						<div class="custom-control custom-radio pb-3">
							<input class="custom-control-input" type="radio" id="customRange" name="filterByDays" checked="checked"/>
							<label for="customRange" class="custom-control-label">Custom</label>
						</div>
						<div class="form-group">
							<div class="input-group">
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
								</div>
								<input type="text" class="form-control float-right" id="customDateRange" />
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-default" data-dismiss="modal" id="applyDateFilter">Apply</button>
				</div>
			</div>
		</div>
	</div>
</template>	
<script>
import { Inertia } from "@inertiajs/inertia";
import {computed} from "vue";
import {usePage, Link} from "@inertiajs/inertia-vue3";

export default {
    components: {
        Link
    },
	created () {
    },
    name: "DateFilter",
    setup(props) {
        const user = computed(() => usePage().props.value.auth.user);
		const getData = usePage().props.value.getData;
		
       const sd = usePage().props.value.new;
       

		const mainSite = usePage().props.value.mainSite;
		const site = usePage().props.value.site;
		var baseURL = jQuery("#baseURL").val();
		var currentLocation = window.location.href;

		
		
		setTimeout(function () {		
            if(
				typeof getData['filterByDays'] !== "undefined" &&
				getData['filterByDays'] == "customRange" &&
				getData.startDate
			){
				jQuery("#customDateRange").daterangepicker({
					
                    startDate: getData.startDate,
                    endDate: getData.endDate,
                    locale: {
                        format: "YYYY-MM-DD",
                    },
                });
				
				jQuery("button[data-target='#dateRangeFilter']").text("Date: "+getData.startDate+" - "+getData.endDate);				
            }
			else{
                jQuery("#customDateRange").daterangepicker({
                    // startDate: moment()
                    //     .subtract(1, "years")
                    //     .startOf("year")
                    //     .format("YYYY-MM-DD"),
					startDate: sd,
                    locale: {
                        format: "YYYY-MM-DD",
                    },
                });
            }
			
            if(
				typeof getData['filterByDays'] !== "undefined" &&
				typeof getData['site'] !== "undefined" &&
				currentLocation.indexOf("/search-by-url") >= 0
			){
				setSiteURLForSearchByUrlFunc(getData['site']);
				jQuery(".card.chart-warpper").css("opacity", 1);
				jQuery("#filter").css("display", "block");
			}
			
			if(
				typeof getData['filterByDays'] !== "undefined" &&
				getData['filterByDays'] != "customRange"
			){
				jQuery("button[data-target='#dateRangeFilter']").text("Date: "+jQuery("label[for='"+getData['filterByDays']+"']").text());
				jQuery("label[for='"+getData['filterByDays']+"']").trigger("click");
			}
			
            jQuery(document).on("click", "#applyDateFilter", function () {
                var startDate, endDate;
                var filterByDays = jQuery("input[name='filterByDays']:checked").attr("id");
				var requestedSite = (jQuery("input[type='search']#searchByURL").length > 0) ? jQuery("input[type='search']#searchByURL").val() : jQuery("#selectedSite option:selected").text();
                jQuery("#ajax-loading").css("display", "flex");

                if (filterByDays == "customRange") {
                    var startDate = jQuery("#customDateRange")
                        .data("daterangepicker")
                        .startDate.format("YYYY-MM-DD");
                    var endDate = jQuery("#customDateRange")
                        .data("daterangepicker")
                        .endDate.format("YYYY-MM-DD");
                }

                var data = {
					
                    site: '',
					siteURL: '',
                    filterByDays: filterByDays,
                    startDate: startDate,
                    endDate: endDate,
					keyword: ((typeof getData['keyword'] !== "undefined") ? getData['keyword'] : ""),
					queryFilter: ((typeof getData['queryFilter'] !== "undefined") ? getData['queryFilter'] : ""),			
					url: ((typeof getData['url'] !== "url") ? getData['url'] : ""),
					pageFilter: ((typeof getData['pageFilter'] !== "undefined") ? getData['pageFilter'] : ""),
					country: ((typeof getData['country'] !== "undefined") ? getData['country'] : ""),
																
                };
				
                setTimeout(function(){
					jQuery("#ajax-loading").css("display", "none");
                },10000);
				
				var requestURL = baseURL+"/report";
				
				if(currentLocation.indexOf("/details/") >= 0){
					requestURL = baseURL+"/details/"+btoa(requestedSite);
				}
				else if(currentLocation.indexOf("/search-by-url") >= 0){
					requestURL = baseURL+"/search-by-url";
				}
				
                Inertia.get(requestURL, data, {});
            });		
		}, 1000); 
		
        function setSiteURLForSearchByUrlFunc(siteURL) {
            jQuery("#selectedSiteURL").html("<a id='selectedSiteDetails' href='"+baseURL+"/details/"+btoa(siteURL)+"'>("+siteURL+")</a>");
			if(jQuery("input[type='search']#searchByURL").length > 0) jQuery("input[type='search']#searchByURL").val(siteURL);
        }		
		
        return {
            user
        }
    }
}
</script>

<style scoped>

</style>

