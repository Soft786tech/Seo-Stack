<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    <meta name="X-CSRF-TOKEN" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link href="<?php echo e(asset('public/dist/css/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/dist/css/icheck-bootstrap/icheck-bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/dist/css/select2/select2.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/dist/css/adminlte.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/dist/css/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/dist/css/datatables/responsive.bootstrap4.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/dist/css/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('public/dist/css/toastr/toastr.min.css')); ?>" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
    <script src="<?php echo e(asset('public/js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('public/dist/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/popper/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/adminlte.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/select2/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('public/dist/js/toastr/toastr.min.js')); ?>"></script>

    

</head>
<style>
    .main-sidebar {
        height: 100% !important;
    }

</style>

<body>
    <input type="hidden" id="baseURL" value="<?php echo e(url('/')); ?>" />
    <div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div>


 <script>
     var x, i, j, l, ll, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
l = x.length;
for (i = 0; i < l; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  ll = selElmnt.length;
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < ll; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h, sl, yl;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        sl = s.length;
        h = this.parentNode.previousSibling;
        for (i = 0; i < sl; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            yl = y.length;
            for (k = 0; k < yl; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, xl, yl, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  xl = x.length;
  yl = y.length;
  for (i = 0; i < yl; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < xl; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);
     </script>

</body>

</html>


<?php /**PATH D:\waqas-projects\htdocs\danialfoley\seo-stack\themes\seo-stack\resources\views/app.blade.php ENDPATH**/ ?>