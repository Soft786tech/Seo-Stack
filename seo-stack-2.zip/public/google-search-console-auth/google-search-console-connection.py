# Credit @tobias_willmann
from google.oauth2 import service_account
from googleapiclient.discovery import build
 
creds = "canvas-modem-335412-2c454e95f712.json"
  
scopes = [
  'https://www.googleapis.com/auth/webmasters',
  'https://www.googleapis.com/auth/webmasters.readonly'
]
 
credentials = service_account.Credentials.from_service_account_file(creds, scopes=scopes)
service = build('searchconsole','v1',credentials=credentials)
 
request = {
  'inspectionUrl': 'https://www.approsoft.com/',
  'siteUrl': 'https://www.approsoft.com/'
}
 
response = service.urlInspection().index().inspect(body=request).execute()
inspectionResult = response['inspectionResult']
print(inspectionResult)