import pickle
import pandas as pd 
import mysql.connector

from datetime import datetime, timedelta
from google_auth_oauthlib.flow import InstalledAppFlow
from apiclient.discovery import build
from datetime import datetime

now = datetime.now()
currentDateTime = now.strftime("%Y-%m-%d %H:%M:%S")

dbObj = mysql.connector.connect(
	host = "localhost",
	user = "root",
	password = "root",
	database = "console_testing" 
)

dbCursor = dbObj.cursor()

dbQuery = "INSERT INTO console_sites_data (site, date, clicks, impressions, ctr, position, keywords, country, created_at, updated_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"

SITE_URL = "https://www.cheekypunter.com/"

OAUTH_SCOPE = ('https://www.googleapis.com/auth/webmasters.readonly', 'https://www.googleapis.com/auth/webmasters')

# Redirect URI for installed apps ("client-id.json")
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'
try:
    flow = InstalledAppFlow.from_client_secrets_file("clide-id-new-user.json", scopes=OAUTH_SCOPE)
    credentials = flow.run_console()
    pickle.dump(credentials, open("config/credentials-new-user.pickle", "wb"))
except (OSError, IOError) as e:
    flow = InstalledAppFlow.from_client_secrets_file("clide-id-new-user.json", scopes=OAUTH_SCOPE)
    credentials = flow.run_console()
    pickle.dump(credentials, open("config/credentials-new-user", "wb"))

quit()
try:
    credentials = pickle.load(open("config/credentials.pickle", "rb"))
except (OSError, IOError) as e:
    flow = InstalledAppFlow.from_client_secrets_file("oceanic-airway-335109-c6040ed73313.json", scopes=OAUTH_SCOPE)
    credentials = flow.run_console()
    pickle.dump(credentials, open("config/credentials.pickle", "wb"))
 
# Connect to Search Console Service using the credentials 
webmasters_service = build('webmasters', 'v3', credentials=credentials)

maxRows = 25000
i = 0
outputRows = []
startDate = datetime.strptime("2021-01-02", "%Y-%m-%d")
endDate = datetime.strptime("2021-01-31", "%Y-%m-%d")


def date_range(startDate, endDate, delta=timedelta(days=1)):
    """
    The range is inclusive, so both startDate and endDate will be returned
    Args:
        startDate: The datetime object representing the first day in the range.
        endDate: The datetime object representing the second day in the range.
        delta: A datetime.timedelta instance, specifying the step interval. Defaults to one day.
    Yields:
        Each datetime object in the range.
    """
    current_date = startDate
    while current_date <= endDate:
        yield current_date
        current_date += delta


for date in date_range(startDate, endDate):
    date = date.strftime("%Y-%m-%d")
    print(date)
    i = 0
    while True:

        request = {
            'startDate' : date,
            'endDate' : date,
            'dimensions' : ["page", "query", "country"],
            "type": "web",
            'rowLimit' : maxRows,
            'startRow' : i * maxRows,
            "aggregationType": "byPage"
        }
        print(i)
        response = webmasters_service.searchanalytics().query(siteUrl = SITE_URL, body=request).execute()
        print(response)
        quit()
        if response is None:
            print("there is no response")
            break
        if 'rows' in response:
            for row in response['rows']: 
                page = row['keys'][0]
                keyword = row['keys'][1]
                country = row['keys'][2]
                value = (page, date, row['clicks'], row['impressions'], row['ctr'], row['position'], keyword, country, currentDateTime, currentDateTime)

                dbRecordStatus = "SELECT id, clicks, impressions, ctr, position FROM console_sites_data WHERE site = %s AND country = %s AND date = %s" 
                dbCursor.execute(dbRecordStatus, (page, country, date))
                results = dbCursor.fetchone()
                
                if results != None:
                  if results[1] < row['clicks']:                        
                    updateQuery = "UPDATE console_sites_data SET clicks = %s, impressions = %s, ctr = %s, position = %s, keywords = %s, country = %s, updated_at = %s WHERE id = %s"  
                    updateValue = ((row['clicks'] + results[1]), (row['impressions'] + results[2]), (row['ctr'] + results[1]), (row['position'] + results[4]), keyword, country, currentDateTime, results[0])
                    print(updateValue)
                    
                    dbCursor.execute(updateQuery, updateValue)				
                    dbObj.commit()
                else:
                  dbCursor.execute(dbQuery, value)				
                  dbObj.commit()  

            if dbCursor.lastrowid >= 1:
                print("Record added successfully: "+page+" :ID: "+str(dbCursor.lastrowid))
            elif dbCursor.rowcount >= 1:
                print("Record updated successfully: "+page+" :ID: "+str(results[0]))
            else:
                print("An error occur while processing your request: "+page) 

            i = i + 1    
            #outputRow = [date, keyword, page, country, device, row['clicks'], row['impressions'], row['ctr'], row['position']]
            #outputRows.append(outputRow)

            
            # quit()
        else:
            print("row not in response: "+SITE_URL)

#df = pd.DataFrame(outputRows, columns=['date','query','page', 'country', 'device', 'clicks', 'impressions', 'ctr', 'avg_position'])
#df.to_csv("gsc_output.csv")