<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\SignupController;
use App\Http\Controllers\SitesController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\CronController;
use App\Http\Controllers\SitesHandlerControler;
use App\Http\Controllers\QueryToolController;
use App\Http\Controllers\ProjectController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('signup', [SignupController::class, 'showSignupForm'])->name('showSignupForm');
Route::post('signup', [SignupController::class, 'authenticate'])->name('signupAuthenticate');
Route::get('userlisting', [SitesHandlerControler::class, 'userlisting'])->name('userlisting');
Route::get('confirm/{id}', [SitesHandlerControler::class, 'confirm'])->name('confirm');



Route::match(['get', 'post'], '/', [LoginController::class, 'showHomePage']);
Route::get('login', [LoginController::class, 'showLoginForm'])->name('showLoginForm');
Route::post('login', [LoginController::class, 'authenticate'])->name('loginAuthenticate');
Route::post('logout', [LoginController::class, 'logout'])->name('logout');
Route::get('dashboard', [SitesController::class, 'showDashboardForm'])->name('showDashboardForm');
Route::get('query-table/{pageID}', [SitesController::class, 'showQueryTableRecords']);
Route::get('test', [SitesController::class, 'test']);
Route::post('dashboard', [SitesController::class, 'showDashboardForm'])->name('showSingleSiteDetails');
Route::post('get-sites-list', [SitesController::class, 'getSitesListing']);
Route::post('export-site-data', [SitesController::class, 'exportSiteData']);
Route::match(['get', 'post'], 'google-search-console-oauth', [SitesController::class, 'googleSearchConsoleOAuth'])->name('googleSearchConsoleOAuth');

Route::match(['get', 'post'], 'search-by-url', [SitesController::class, 'getResultByInsertedSiteURL'])->name('getResultByInsertedSiteURL');
Route::match(['get', 'post'], '/details/{siteID?}/{site?}', [SitesController::class, 'showSiteDetails'])->name('showSiteDetails');
// Route::get('/details/{siteID?}/{site?}', [SitesController::class, 'showSiteDetails'])->name('sitedetailByfilter');
Route::get('refresh-token', [CronController::class, 'refreshGoogleAccessToken']);
Route::get('update-sites', [CronController::class, 'updateAccountSites']);
//add site routes
Route::get('Sites', [SitesHandlerControler::class, 'index'])->name('addsite');
Route::get('viewsites', [SitesHandlerControler::class, 'viewsites'])->name('viewsites');
Route::get('delweb/{id}', [SitesHandlerControler::class, 'destroy'])->name('delweb');
Route::post('savesites', [SitesHandlerControler::class, 'store'])->name('savewebsite');
Route::get('Sites/{id}/edit', [SitesHandlerControler::class, 'edit']);
Route::post('Sites/{id}/updatesite', [SitesHandlerControler::class, 'update'])->name('updatesite');
//add site routes
// Route::get('report', [ReportController::class, 'showReports'])->name('showReports');
// Route::get('report/query-table/{pageID}', [ReportController::class, 'showQueryTableRecords']);
// Route::post('export-query-data', [ReportController::class, 'exportSiteData']);
Route::get('query', [QueryToolController::class, 'showDashboardForm'])->name('showQuery');
Route::get('query/query-table/{pageID}', [QueryToolController::class, 'showQueryTableRecords']);
Route::post('export-query-row-data', [QueryToolController::class, 'exportSiteData']);
Route::post('query', [QueryToolController::class, 'showDashboardForm'])->name('showSingleSiteDetailsQuery');
Route::get('query/query-table/{pageID}', [QueryToolController::class, 'showQueryTableRecords']);

Route::get('project', [ProjectController::class, 'showDashboardFormNew'])->name('showPorject');
Route::post('project', [ProjectController::class, 'showDashboardFormNew'])->name('showSingleSiteDetailsProject');
Route::match(['get', 'post'], '/clear-cache/{isCron?}', function ($isCron = 0) {
    Artisan::call('cache:clear');
    Artisan::call('route:cache');
    Artisan::call('config:cache');
    Artisan::call('view:clear');

    if (!$isCron) return redirect('/');
});





