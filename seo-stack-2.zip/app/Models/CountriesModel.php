<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CountriesModel extends Model
{
	protected $table = 'countries';
	protected $primaryKey = 'id';
	public $timestamps = true;
	
    protected $fillable = [
        'name', 'iso_code', 'created_at', 'updated_at',
    ];	
}
