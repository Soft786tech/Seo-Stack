<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConsoleSitesModel extends Model
{
	protected $table = 'console_sites';
	protected $primaryKey = 'id';
	public $timestamps = true;
	
    protected $fillable = [
        'sites', 'created_at', 'updated_at',
    ];	
}
