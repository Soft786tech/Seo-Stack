<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConsoleSitesDataModel extends Model
{
	protected $table = 'console_sites_data';
	protected $primaryKey = 'id';
	public $timestamps = true;
	
    protected $fillable = [
        'site', 'date', 'clicks', 'impressions', 'ctr', 'position', 'keywords', 'created_at', 'updated_at',
    ];	
}
