<?php

namespace App\Console\Commands;
   
use Illuminate\Console\Command;
   
class Crons extends Command
{
	protected $signature = 'googleAccessToken:cron';
	protected $description = 'Command description';
	
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        \Log::info("Cron is working fine!");
     
        /*
           Write your database logic we bellow:
           Item::create(['name'=>'hello new']);
        */
    }	
}