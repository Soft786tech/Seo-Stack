<?php

namespace App\Http\Controllers;

use App\Models\ConsoleSiteInfo;
use App\Models\ConsoleTokenModel;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Inertia\Inertia;
use SebastianBergmann\Environment\Console;
use Google_Client;
use Google_Service_Webmasters;
use App\Models\Userlisting;
use App\Models\User;
use Illuminate\Support\Facades\Schema;


class SitesHandlerControler extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public $sitesArr = [];
    public $dbsties = [];
    public function __construct()
    {
        $this->dbsties = ConsoleSiteInfo::all()->toArray();
        foreach ($this->dbsties as $dbsite) {
            array_push($this->sitesArr, $dbsite['siteUrl']);
        }
    }
    public function index()
    {

        return Inertia::render('sites/main', [
            "sites" => $this->sitesArr,
        ]);
    }




    public function userlisting(Request $req)
    {
        $sitescrud = User::where('user_type','!=','super_admin')->orderBy('id', 'desc')->get();
        return Inertia::render('sites/Listinguser', [
            "sites" => $this->sitesArr,
            "sitescrud" => $sitescrud,
        ]);
    }






    public function confirm(Request $req){
    
        $idd = $req->id;
        $id = User::find($idd);
        $status = $id->status;
        if($status == 1){
            $update = User::find($idd);
            $update->status = 0;
            $update->save();
            return redirect('userlisting');
        }
        
        $update = User::find($idd);
        $update->status = 1;
        $update->save();


       


        $y = Schema::hasTable("userinfo_new_$idd"); 
        if($y == 1){
            return redirect('userlisting'); 
        }else{
        Schema::create("console_site_infos_$idd", function($table)
        {           
           $table->increments('id');
           $table->text('siteUrl');
           $table->text('permissionLevel');
           $table->integer('u_id');
           $table->datetime('created_at');
           $table->datetime('updated_at');

        });


        return redirect('userlisting');
    }

        
    }

    






    public function viewsites()
    {
        $sitescrud = DB::table('console_site_infos')->orderBy('id', 'desc')->get();
        return Inertia::render('sites/ViewSite', [
            "sites" => $this->sitesArr,
            "sitescrud" => $sitescrud,
        ]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return Inertia::render('sites/Addsites');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try {

            $dataToken = ConsoleTokenModel::all();
            $tokenPath = public_path('/client_secret.json');
            $last2Days = date('Y-m-d', strtotime("-3 days"));
            $curDate = date('Y-m-d');
            $client = new Google_Client();
            $client->setAccessToken($dataToken[0]->token_data);
            $client->setAuthConfig($tokenPath);
            $service = new Google_Service_Webmasters($client);
            $q = new \Google_Service_Webmasters_SearchAnalyticsQueryRequest();
            $q->setStartDate($last2Days);
            $q->setEndDate($curDate);
            $q->setDimensions(['page', 'date']);
            $q->setSearchType('web');
            $u = $service->searchanalytics->query($request->siteUrl, $q);
            $data = new ConsoleSiteInfo();
            $data->siteUrl = $request->siteUrl;
            $data->save();
            return redirect()->back()->with('success', 'Data save successfully ..!!');
        } catch (Exception $e) {
            return redirect()->back()->withErrors(['errors' => $request->siteUrl . " is not a valid Search Console site URL"]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $commingSite = ConsoleSiteInfo::find($id);
        return Inertia::render('sites/Edit', [
            'commingSite' => $commingSite,
            "sites" => $this->sitesArr,

        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $data = ConsoleSiteInfo::find($request->id);
        $data->siteUrl = $request->siteUrl;
        $data->permissionLevel = $request->permissionLevel;
        $data->save();
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('console_site_infos')->where('id', $id)->delete();
        return redirect('viewsites');
    }
}
