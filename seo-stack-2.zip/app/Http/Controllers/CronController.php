<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ConsoleSitesModel;
use App\Models\ConsoleTokenModel;
use App\Models\ConsoleSitesDataModel;
use App\Models\ConsoleSiteInfo;
use Google_Client; 
use Google_Service_Webmasters; 

class CronController extends Controller
{
    public function __construct() {
		$this->redirectURI = url('/refresh-token');
        $this->credentials = public_path('/credentials.json');
    }
	
	public function refreshGoogleAccessToken(){
		$tokenPath = public_path('/client_secret.json');
		$client = new \Google_Client();
		$client->setAuthConfig($tokenPath);
		$client->setRedirectUri($this->redirectURI);
		$client->addScope("https://www.googleapis.com/auth/webmasters");
		$client->addScope("https://www.googleapis.com/auth/spreadsheets");
		$client->setAccessType('offline');
		$client->setIncludeGrantedScopes(true);		
		$client->setApprovalPrompt('force');
		
		$accessToken = ConsoleTokenModel::select(["token_data"])->where('id', 1)->get()->toArray();
		$accessToken = isset($accessToken[0]['token_data']) ? json_decode($accessToken[0]['token_data'], true) : [];		
		
		if(isset($_GET['code'])){
            $authCode = $_GET['code'];
            $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
            $client->setAccessToken($accessToken);
			$refreshToken = $client->getRefreshToken();	

            if(array_key_exists('error', $accessToken)){
                throw new Exception(join(', ', $accessToken));
            }			
			
			$this->storeConsoleAccessToken(json_encode($client->getAccessToken()));
			\Log::info("Token Successfully Generated!");			
		}
		
		if(!empty($accessToken)){
			$client->setAccessToken($accessToken);
			
			if(isset($accessToken['access_token'])){
				$ch = curl_init();

				curl_setopt($ch, CURLOPT_URL, 'https://searchconsole.googleapis.com/webmasters/v3/sites?key=AIzaSyC_9uPfq4llv-isogxeAnoaA4UFygiQfn4');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

				curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

				$headers = [];
				$headers[] = 'Authorization: Bearer '.$accessToken['access_token'];
				$headers[] = 'Accept: application/json';
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

				$result = curl_exec($ch);
				$response = json_decode($result, true);
				
				if(curl_errno($ch)){
				}
				else{
					$dbSites = [];
					$allSites = ConsoleSiteInfo::select(['id', 'siteUrl'])->get()->toArray();
					foreach($allSites as $allSite){
						if(isset($allSite['id']) && isset($allSite['siteUrl'])) $dbSites[$allSite['id']] = $allSite['siteUrl'];
					}
					
					if(
						isset($response['siteEntry'][0]) && 
						!empty($response['siteEntry'][0])
					){
						foreach($response['siteEntry'] as $siteEntry){
							if(
								isset($siteEntry['siteUrl']) &&
								in_array($siteEntry['siteUrl'], $dbSites)
							){
								$siteID = array_search(trim($siteEntry['siteUrl']), $dbSites);
								if($siteID) ConsoleSiteInfo::where('id', $siteID)->update(["status" => 1]);
							}
						}
					}
				}
				
				curl_close($ch);
				exit;
			}			
		}		

		if(
 			/* $client->isAccessTokenExpired() && */
			$client->getRefreshToken()
		){
			$client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
			$this->storeConsoleAccessToken(json_encode($client->getAccessToken()));
			/* $this->updateAccountSites(json_encode($client->getAccessToken())); */
			\Log::info("Token Successfully Refresh!");
		}
		
		echo $authUrl = $client->createAuthUrl();
	}
	
	public function storeConsoleAccessToken($accessToken){
		if(!empty($accessToken)){			
			$tokenData = ConsoleTokenModel::where('id', 1)->get()->toArray();
				
			$accessToken = ['token_data' => $accessToken];
			if(!empty($tokenData)) ConsoleTokenModel::where('id', 1)->update($accessToken);
			else ConsoleTokenModel::create($accessToken);		
		}
	}
	
	public function updateAccountSites($accessToken='{"access_token":"ya29.a0ARrdaM9DTmLMEapfAky1D4chUmz7w6nfUWOfZFKIXSzTvEOT9dG8hJP3ykG155OPctL7erAc71rg6VIIQ3gpqyyR1j1DgS0QtJX6pHIpVmg-EssazEQWIBZaQdV6UOIBOGq3kRp0HMYQ61vC4lToV6FnUN_i","expires_in":3599,"refresh_token":"1\/\/03t2BZeBQo72XCgYIARAAGAMSNwF-L9IrytkgvBnV5mVHJkAUPkXuWGl19ownXYy_Ulbo9ZAnXvn15nz5cbQLW_BZuLgGpcJl1xE","scope":"https:\/\/www.googleapis.com\/auth\/spreadsheets https:\/\/www.googleapis.com\/auth\/webmasters","token_type":"Bearer","created":1653048223}'){
		if(!empty($accessToken)){			
			$last2Days = date('Y-m-d', strtotime("-3 days"));
			$last2Days = date('Y-m-d', strtotime("2022-04-01"));
			$curDate = date('Y-m-d', strtotime("2022-04-01"));
			/* $curDate = date('Y-m-d'); */
/* 			
Forbidden
			'sc-domain:bonuscodepoker.com' 
			'sc-domain:bettingofferstoday.co.uk'
			'https://icash.ca/'
			'https://the-whiskey-club.co.uk/'
			'https://myofficepods.com/'
			*/
			
$alreadyAdded = [
	'https://www.cheekypunter.com/',
	'https://acdesignsolutions.co.uk/',
	'sc-domain:mcsrentalsoftware.com',
	'https://www.beaconfaceanddermatology.ie/',
	'sc-domain:perspectivepictures.com',
	'https://the-whiskey-club.co.uk/',
	'https://www.mcsrentalsoftware.com/de/',
	'https://www.skillstg.co.uk/',
	'sc-domain:yorkshirefabricshop.com',
	'https://www.claims.co.uk/',
	'https://www.solmarvillas.com/',
	'https://www.hometree.co.uk/',
	'https://myofficepods.com/',
	'https://www.thevapecig.co.uk/',
	'https://www.claims4free.co.uk/',
	'https://www.mcsrentalsoftware.com/es/',
	'https://www.replaceyourdoc.com/',
	'https://whiskey-wealth-club-investment-review.co.uk/',
	'https://www.assertive-media.co.uk/',
	'https://www.replaceyourdocuments.com/',
	'https://www.windows-doors-uk.co.uk/',
	'sc-domain:assertive-media.co.uk',
	'https://www.manhattantechsupport.com/',
	'sc-domain:skuuudle.com',
	'sc-domain:vitaminology.co',
	'https://skuuudle.com/',
	'https://syntax.co.uk/',
	'https://www.pharmacyonline.co.uk/',
	'https://impeldynamic.com/',
	'sc-domain:officefurnitureonline.co.uk',
	'https://www.planday.com/',
	'https://www.mcsrentalsoftware.com/se/',
	'https://comparegolfprices.co.uk/',
	'https://www.mcsrentalsoftware.com/au/',
	'https://onlinenoveltydoc.com/',
	'https://www.mcsrentalsoftware.com/nl/',
	'https://www.mcsrentalsoftware.com/us/',
	'http://comparegolfprices.co.uk/',
	'https://www.mcsrentalsoftware.com/za/',
	'https://www.thefitnesscircle.co.uk/',
	'sc-domain:raylo.com',
	'https://www.kambizgolchin.com/',	
	'https://www.quotezone.co.uk/',	
	'https://www.bumper.co.uk/',	
	'sc-domain:quotezone.co.uk',
	'sc-domain:bumper.co.uk',
	'sc-domain:mortgageadvice.biz',
	'https://ifloodedrestoration.com/',
	'https://imagehair.co/',
	'https://www.eightieskids.com/',
	'https://www.88vape.com/',
	'sc-domain:bonuscodepoker.com',
	'sc-domain:gro.team',
	'https://www.mcsrentalsoftware.com/fr/',
	'https://www.misteliquid.co.uk/',
	'sc-domain:dangler.co.uk',
	'sc-domain:bettingofferstoday.co.uk'
];			

 			$client = new Google_Client();
			$client->setAccessToken($accessToken);
			$service = new Google_Service_Webmasters($client);
			$query = new \Google_Service_Webmasters_SearchAnalyticsQueryRequest();
			$query->setStartDate($last2Days);
			$query->setEndDate($curDate);
			$query->setDimensions(['page', 'date', 'query', 'country']);
			$query->setSearchType('web');	
			$consoleSites = ConsoleSitesModel::where('id', 1)->get()->toArray(); 
			
			$sites = (isset($consoleSites[0]['sites']) && !empty($consoleSites[0]['sites'])) ? json_decode($consoleSites[0]['sites'], 'true') : [];
			
			if(
				isset($sites['siteEntry'][0]['siteUrl']) &&
				!empty($sites['siteEntry'][0]['siteUrl'])
			){				
				foreach($sites['siteEntry'] as $site){
					if(
						isset($site['siteUrl']) &&
						isset($site['permissionLevel']) &&
						$site['permissionLevel'] == "siteFullUser"
					){						
						if(in_array($site['siteUrl'], $alreadyAdded)) continue;
						
						$sitesData = $service->searchanalytics->query($site['siteUrl'], $query);	

						if(!empty($sitesData)){
							$bashDataInsertion = [];
							
							for($counter = 0; $counter < count($sitesData->rows); $counter++){
								$siteURL = (isset($sitesData->rows[$counter]->keys[0]) ? $sitesData->rows[$counter]->keys[0] : "");
								
								if(!empty($siteURL)){					
									$date = (isset($sitesData->rows[$counter]->keys[1]) ? $sitesData->rows[$counter]->keys[1] : "");
									$keywords = (isset($sitesData->rows[$counter]->keys[2]) ? $sitesData->rows[$counter]->keys[2] : "");
									$country = (isset($sitesData->rows[$counter]->keys[3]) ? $sitesData->rows[$counter]->keys[3] : "");
									
									$data = [
										'site' => $siteURL,
										'date' => $date,
										'clicks' => (isset($sitesData->rows[$counter]->clicks) ? $sitesData->rows[$counter]->clicks : 0),
										'impressions' => (isset($sitesData->rows[$counter]->impressions) ? $sitesData->rows[$counter]->impressions : 0),
										'ctr' => (isset($sitesData->rows[$counter]->ctr) ? $sitesData->rows[$counter]->ctr : 0),
										'position' => (isset($sitesData->rows[$counter]->position) ? $sitesData->rows[$counter]->position : 0),
										'keywords' => $keywords,
										'country' => $country
									];

									$sites = ConsoleSitesDataModel::where(['site' => $siteURL, 'date' => $date])->get()->toArray();

									if(!empty($sites)){
										if(
											isset($sites[0]['id']) &&
											isset($sites[0]['clicks']) &&
											$sites[0]['clicks'] < $data['clicks']						
										){		
											ConsoleSitesDataModel::where('id', $sites[0]['id'])->update($data);
										}
									}
									else{
										$bashDataInsertion[] = $data; 			
									}			
								}
							}
							
							ConsoleSitesDataModel::insert($bashDataInsertion);
						} 
						
						echo "<br>SiteUrl: ".$site['siteUrl'];
					}	
					
				}
			}	
		}
	}
}