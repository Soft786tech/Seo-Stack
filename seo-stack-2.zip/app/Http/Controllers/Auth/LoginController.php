<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use App\Models\User;
/* use Illuminate\Support\Facades\Hash; */


class LoginController extends Controller
{
    public function showHomePage()
    {
        return view('home');
    }


    public function showLoginForm()
    {
        return Inertia::render('Auth/Login');
    }



    public function authenticate(Request $request)
    {
        $credentials = $this->validate($request, [
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);

          
        if (Auth::attempt($credentials) && User::select('status')->where('email',$credentials['email'])->get()->first()->status == 1) {
            
            $request->session()->regenerate();
            return redirect()->intended('/dashboard');

        }
        
        
        if(Auth::attempt($credentials) && User::select('status')->where('email',$credentials['email'])->get()->first()->status == 0){

            return back()->withErrors([
                'email' => 'Plz wait untill you recieve confirmation email from the admin thank you!',
            ]);  

        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);

    }




    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->intended('/login');
    }
}
