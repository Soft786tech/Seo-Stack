<?php

namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use App\Models\User;

use Illuminate\Support\Facades\Hash;


class SignupController extends Controller
{
    


    public function showSignupForm()
    {
        return Inertia::render('Auth/Signup');
    }


    public function authenticate(Request $request)
    {
        $credentials = $this->validate($request, [
            'name'     => ['required'],
            'email'    => ['required', 'email'],
            'password' => ['required'],
           
        ]);
      $name     = $request->name;
      $email    = $request->email;
      $password = $request->password; 
      $check = User::where('email',$email)->get();
      if(count($check) == 1){
        return back()->withErrors([
            'email' => 'The provided email is already exist.',
        ]);  
      }else{
        
        $password = $password;
        $hash = Hash::make($password);
        
        $user = User::create([
         'name'      => $name,
         'email'     => $email,
         'password'  => $hash
        ]);

        $userid = $user->id;

        return Inertia::render('Auth/verify-email')->with(['username'=>$name]);
    
      }


    

        
        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);
    }


   


}
