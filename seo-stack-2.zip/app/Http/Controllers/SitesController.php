<?php



namespace App\Http\Controllers;



use App\Http\Controllers\Controller;
use App\Http\Controllers\PaginationController;
use App\Models\ConsoleSiteInfo;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\Models\ConsoleSitesModel;
use App\Models\CountriesModel;
use App\Models\ConsoleTokenModel;
use App\Models\UserApiCredentials;

use App\Models\ConsoleSitesDataModel;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

use Google_Service_Sheets_Spreadsheet;
/* use Illuminate\Support\Facades\Hash; */





class SitesController extends Controller

{

    private $pageLimit;
    private $paginationObj;

    public function __construct()
    {
      $this->pageLimit = 10;
		  $this->paginationObj = new PaginationController;
      $this->googleRedirectURI = url('/export-site-data');
      $this->tokenFile = public_path("token_file_x.json");
      $this->sheetFile = public_path("sheetFile.json");
    }


    public function showDashboardForm(Request $request)
    {
        $sites = $siteData = $keywordDetails = [];

        $startDate = $endDate = $pagination = "";
        $postData = ($request->isMethod('post')) ? $request->input() : [];
        $getData = ($request->isMethod('get')) ? $request->input() : [];

        $sitesUrls = ConsoleSitesModel::select(["sites"])->distinct()->get()->toArray();
        $countries = CountriesModel::select(["name", "iso_code"])->distinct()->get()->toArray();

        if (isset($sitesUrls[0]['sites'])){
            $sitesUrls = json_decode($sitesUrls[0]['sites'], true);

            $sitesUrls = isset($sitesUrls['siteEntry']) ? $sitesUrls['siteEntry'] : [["siteUrl" => "https://www.leisurebuildings.com/", "permissionLevel" => "siteFullUser"]];
            $siteURL = "";
            foreach ($sitesUrls as $site) {
                if (isset($site['siteUrl']) && !empty($site['siteUrl']) && isset($site['permissionLevel']) && $site['permissionLevel'] == "siteFullUser") {
                    if (empty($siteURL)) $siteURL = $site['siteUrl'];
                    $sites[] = $site['siteUrl'];

                }
            }


            $siteURL = trim((isset($postData['site'])) ? $postData['site'] : ((isset($getData['site'])) ? $getData['site'] : ((isset($getData['url'])) ? $getData['url'] : $siteURL)));
            $where = ['site' => $siteURL];


			$getData['filterByDays'] = (isset($getData['filterByDays']) && !empty($getData['filterByDays'])) ? $getData['filterByDays'] : "last6Months";
			$dateRange = $this->getStartEndDateByFilterType($getData['filterByDays'], (isset($getData["startDate"]) ? $getData["startDate"] : ""), (isset($getData["endDate"]) ? $getData["endDate"] : ""));
			$startDate = isset($dateRange[0]) ? $dateRange[0] : "";
			$endDate = isset($dateRange[1]) ? $dateRange[1] : "";

			$where = [
				['site', '=', $siteURL],
				['date', '>=', $startDate],
				['date', '<=', $endDate],
			];

			$where = $this->searchFilterAgainstType($where, $getData);

            $siteData = ConsoleSitesDataModel::select(["site", "date", "clicks", "impressions", "ctr", "position"])->where($where)->get()->toArray();

			$t = ConsoleSitesDataModel::min('date');
			$getData['defaultSiteURL'] = (isset($getData['url']) && !empty($getData['url'])) ? $getData['url'] : "";

			if(
				isset($getData['url']) &&
				isset($getData['siteURL']) &&
				isset($siteData[0]['site']) &&
				!filter_var($getData['url'], FILTER_VALIDATE_URL)
			){

				$getData['siteURL'] = $siteData[0]['site'];

			}
			else if(isset($getData['site'])){

				$getData['siteURL'] = $getData['url'] = $getData['site'];

			}

			$keywordDetails = $this->getSiteKeywordsDetails(0, 'clicks', 'ASC', $where, (isset($getData['page']) ? $getData['page'] : 0),10);
	        $total =  $keywordDetails['total'];
        }

        $sitesArr = [];
        $dbsties = ConsoleSiteInfo::all()->toArray();

        foreach ($dbsties as $dbsite) {
            array_push($sitesArr, $dbsite['siteUrl']);
        }
        // perday
        $clicks = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $clicks += $siteData[$i]['clicks'];

        }
        // impressions
        $impressions = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $impressions += $siteData[$i]['impressions'];
        }

        // Sumforaverageposition
        $positionavaeragesum = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $positionavaeragesum += $siteData[$i]['position'];
        }
        // Sumforaveragectr
        $Sumforaveragectr = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $Sumforaveragectr += $siteData[$i]['ctr'];
        }

		return Inertia::render('Dashboard', [
            "sites" => $sites,
            "countries" => $countries,
            "siteData" => $siteData,
            "getData" => $getData,
            "averagectr" => number_format($Sumforaveragectr, 2),
            "positionaverage" => $positionavaeragesum,
            "clicks" => $clicks,
            "impressions" => $impressions,
            "startDate" => $startDate,
            "endDate" => $endDate,
            "keywordDetails" => $keywordDetails['keywordDetails'],
            "pagination" => $keywordDetails['pagination'],
			"rel"       => $total,
			"pass"      => 10,
			"new"       => $t
        ]);
    }

	public function showQueryTableRecords(Request $request){

		$keywordDetails = [];
		$getData = ($request->isMethod('get')) ? $request->input() : [];
        $t = $getData['to'];


		if(
			isset($getData['page']) &&
			$getData['page'] &&
			isset($getData['siteURL']) &&
			$getData['siteURL']
		){
			$getData['filterByDays'] = (isset($getData['filterByDays']) && !empty($getData['filterByDays'])) ? $getData['filterByDays'] : "last6Months";
			$dateRange = $this->getStartEndDateByFilterType($getData['filterByDays'], (isset($getData["startDate"]) ? $getData["startDate"] : ""), (isset($getData["endDate"]) ? $getData["endDate"] : ""));
			$startDate = isset($dateRange[0]) ? $dateRange[0] : "";
			$endDate = isset($dateRange[1]) ? $dateRange[1] : "";

			$where = [
				['site', 'LIKE', $getData['siteURL']."%"],
				['date', '>=', $startDate],
				['date', '<=', $endDate],
			];

			$offset = ($getData['page'] - 1) * $this->pageLimit;


			$orderBy = isset($getData['orderBy']) ? $getData['orderBy'] : "clicks";
			$order = isset($getData['order']) ? $getData['order'] : "asc";

			$where = $this->searchFilterAgainstType($where, $getData);

			$keywordDetails = $this->getSiteKeywordsDetails($offset, $orderBy,$order, $where, (isset($getData['page']) ? $getData['page'] : 0),$t);



		}

		print json_encode($keywordDetails);

	}


    public function showSiteDetails(Request $request, $siteURL = "", $site = "")
    {
		$orderBy = $order = "";
		$defaultSiteURL = $siteURL;
        $siteData = $sitePages = $keywords = $pagesClicks = $keywordDetails = [];
		$getData = ($request->isMethod('get')) ? $request->input() : [];
        $offset = ($site && is_numeric($site)) ? (($site - 1) * $this->pageLimit) : 0;

		$countries = CountriesModel::select(["name", "iso_code"])->distinct()->get()->toArray();


        if(
			!empty($siteURL) ||
			!empty($request->siteURL)
		){
            if ($request->siteURL) {
                $siteURL = base64_decode($request->siteURL);
            }
			else {
                $siteURL = base64_decode($siteURL);
            }

			if(strpos($siteURL, "|orderBy|") !== false){
				$siteURL = explode("|orderBy|", $siteURL);
				$orderBy = isset($siteURL[1]) ? $siteURL[1] : "";
				$order = isset($siteURL[2]) ? $siteURL[2] : "ASC";
				$siteURL = isset($siteURL[0]) ? $siteURL[0] : "";
			}

            $site = ($site && !is_numeric($site)) ? base64_decode($site) : "";

			$getData['filterByDays'] = (isset($getData['filterByDays']) && !empty($getData['filterByDays'])) ? $getData['filterByDays'] : "last6Months";
			$dateRange = $this->getStartEndDateByFilterType($getData['filterByDays'], (isset($getData["startDate"]) ? $getData["startDate"] : ""), (isset($getData["endDate"]) ? $getData["endDate"] : ""));
			$startDate = isset($dateRange[0]) ? $dateRange[0] : "";
			$endDate = isset($dateRange[1]) ? $dateRange[1] : "";

			$where = [
				['site', '=', $siteURL],
				['date', '>=', $startDate],
				['date', '<=', $endDate],
			];

			$where = $this->searchFilterAgainstType($where, $getData);
            $siteData = ConsoleSitesDataModel::select(["date", "clicks", "impressions", "ctr", "position"])->where($where)->get()->toArray();

			$where = [
				['site', 'LIKE', "%".($site ? $site : $siteURL).(!isset($getData['queryFilter']) ? '%' : '')],
				['date', '>=', $startDate],
				['date', '<=', $endDate],
			];

			$where = $this->searchFilterAgainstType($where, $getData);
            $pages = ConsoleSitesDataModel::select(["site", "keywords"])->distinct()->where($where)->get()->toArray();

			$sitePages[($site ? $site : $siteURL)] = ($site ? $site : $siteURL);

            if (!empty($pages)) {
                foreach ($pages as $page) {
                    if (isset($page['site']) && !empty($page['site'])) {
                        if (isset($page['keywords']) && !empty($page['keywords'])) $keywords[$page['keywords']] = $page['keywords'];
                        $sitePages[$page['site']] = $page['site'];
                    }
                }
            }
        }


        $totalPages = $totalRecords = 0;
        if (!empty($keywords)) {

            $totalPages = ceil(count($keywords) / $this->pageLimit);
            $totalRecords = count($keywords);



            $keywordsLimit = array_slice($keywords, $offset, $this->pageLimit, true);


            $keywordDetails = $this->calculateClicksImpressionsAgainstKeywords(ConsoleSitesDataModel::select(["site", "date", "clicks", "impressions", "ctr", "position", "keywords"])->whereIn("keywords", $keywordsLimit)->get()->toArray());



			if(
				!empty($orderBy) &&
				!empty($order)
			){
				$orderTypes = [
					'clicks' => 'totalClicks',
					'impressions' => 'totalImpressions',
					'ctr' => 'totalCtr',
					'pos' => 'totalPosition',
				];

				array_multisort(array_column($keywordDetails, $orderTypes[$orderBy]), ($order == "desc" ? SORT_DESC : SORT_ASC), $keywordDetails);
			}
        }

		$baseURL = url("/details/".$defaultSiteURL);
		$pagination = $this->paginationObj->showPaginationsFunc($totalRecords, $this->pageLimit, [$baseURL, 'page', 0, 0], 1, 0, 1);




        $data = [
            "sites" => [],
            "site" => $siteURL,
            "mainSite" => $site,
			"countries" => $countries,
            "siteData" => $siteData,
            "getData" => $getData,
            "sitePages" => $sitePages,
            "pagination" => $pagination,
            "orderBy" => $orderBy,
            "order" => $order,
            "keywords" => json_encode($keywords),
            "totalPages" => $totalPages,
            "keywordDetails" => $keywordDetails,
            "startDate" => isset($startDate) ? $startDate : '',
            "endDate" => isset($endDate) ? $endDate : '',
			"rel"    => $totalRecords,
			"pass"  => 10,
        ];


        return Inertia::render('SiteDetails', $data);
    }

	function searchFilterAgainstType($where, $getData){
		if(
			isset($getData['queryFilter']) &&
			isset($getData['keyword']) &&
			!empty($getData['keyword'])
		){
			$operator = "";
			if($getData['queryFilter'] == "queriesContaining") $operator = "LIKE";
			else if($getData['queryFilter'] == "queriesNotContaining") $operator = "NOT LIKE";
			else if($getData['queryFilter'] == "exactQuery") $operator = "=";

			if(!empty($operator)){
				if($where[0][0] == "site"){
					$where[0][1] = "LIKE";
					$where[0][2] = $where[0][2].'%';
				}

				$keyword = ($getData['queryFilter'] == "queriesContaining") ? '%'.$getData['keyword'].'%' : $getData['keyword'];
				array_push($where, ['keywords', $operator, $keyword]);
			}
		}

		if(
			isset($getData['pageFilter']) &&
			isset($getData['url']) &&
			!empty($getData['url'])
		){
			$operator = "";
			if($getData['pageFilter'] == "urlsContaining") $operator = "LIKE";
			else if($getData['pageFilter'] == "urlsNotContaining") $operator = "NOT LIKE";
			else if($getData['pageFilter'] == "exactUrl") $operator = "=";

			if(!empty($operator)){
				unset($where[0]);
				$url = ($getData['pageFilter'] == "urlsContaining") ? '%'.$getData['url'].'%' : $getData['url'];
				array_push($where, ['site', $operator, $url]);
				$where = array_values($where);
			}
		}

		if(
			isset($getData['country']) &&
			!empty($getData['country'])
		){
			if($where[0][0] == "site"){
				$where[0][1] = "LIKE";
				$where[0][2] = $where[0][2].'%';
			}
			array_push($where, ['country', '=', $getData['country']]);
		}

		return $where;
	}

	private function getSiteKeywordsDetails($offset, $orderBy, $order, $where, $paged,$t){

		$pagination = "";
		$keywordDetails = [];
		$totalPages = $totalRecords = 0;

		if(!empty($where)){
			if(
				isset($where[0][0]) &&
				$where[0][0] == "site"
			){
				if(strpos($where[0][2], "%") !== false) $where[0][2] = rtrim($where[0][2], "%");

				$where[0][1] = "LIKE";
				$where[0][2] = $where[0][2].'%';
			}

			$pages = ConsoleSitesDataModel::select(["site", "keywords"])->distinct()->where($where)->get()->toArray();


			if (!empty($pages)) {
				foreach ($pages as $page) {
					if (isset($page['site']) && !empty($page['site'])) {
						if (isset($page['keywords']) && !empty($page['keywords'])) $keywords[$page['keywords']] = $page['keywords'];
						$sitePages[] = $page['site'];
					}
				}
			}

			if (!empty($keywords)) {
				$totalPages = ceil(count($keywords) / $t);

				$totalRecords = count($keywords);



				$keywordsLimit = array_slice($keywords, $offset, $t, true);


				$keywordDetails = $this->calculateClicksImpressionsAgainstKeywords(ConsoleSitesDataModel::select(["site", "date", "clicks", "impressions", "ctr", "position", "keywords"])->whereIn("keywords", $keywordsLimit)->get()->toArray());



				if(
					!empty($orderBy) &&
					!empty($order)
				){
					$orderTypes = [
						'clicks' => 'totalClicks',
						'impressions' => 'totalImpressions',
						'ctr' => 'totalCtr',
						'pos' => 'totalPosition',
					];

					array_multisort(array_column($keywordDetails, $orderTypes[$orderBy]), ($order == "desc" ? SORT_DESC : SORT_ASC), $keywordDetails);
				}
			}

			$baseURL = url("/dashboard");

			$pagination = $this->paginationObj->showPaginationsFunc($totalRecords, $t, [$baseURL, 'page', 0, 0], 1, 0, 1);


		}

		return [
			"keywordDetails" => $keywordDetails,
			"pagination" => $pagination,
			"total"     => $totalRecords,
			"per"      => $t,

		];
	}

	private function getStartEndDateByFilterType($filterByDays, $defaultStartDate="", $defaultEndDate=""){
		$endDate = date("Y-m-d");

		switch ($filterByDays) {
			case "last7Days":
				$startDate = date("Y-m-d", strtotime("-7 days"));
				break;
			case "last28Days":
				$startDate = date("Y-m-d", strtotime("-28 days"));
				break;
			case "last3Months":
				$startDate = date("Y-m-d", strtotime("-3 months"));
				break;
			case "last6Months":
				$startDate = date("Y-m-d", strtotime("-6 months"));
				break;
			case "last12Months":
				$startDate = date("Y-m-d", strtotime("-12 months"));
				break;
			case "last16Months":
				$startDate = date("Y-m-d", strtotime("-16 months"));
				break;
			case "customRange":
				$startDate = (!empty($defaultStartDate) ? $defaultStartDate : date("Y-m-d"));
				$endDate = (!empty($defaultEndDate) ? $defaultEndDate : date("Y-m-d"));
				break;
			default:
				$startDate = "";
				$endDate = "";
				break;
		}

		return [$startDate, $endDate];
	}

    public function calculateClicksImpressionsAgainstKeywords($pageDetails){

        $keywordDetails = [];



        if (!empty($pageDetails)) {
            foreach ($pageDetails as $pageData) {
                if (isset($keywordDetails[$pageData['keywords']])) {

                    $keywordDetails[$pageData['keywords']]["totalClicks"] = $keywordDetails[$pageData['keywords']]["totalClicks"] + $pageData['clicks'];

                    $keywordDetails[$pageData['keywords']]["totalImpressions"] = $keywordDetails[$pageData['keywords']]["totalImpressions"] + $pageData['impressions'];
                    $keywordDetails[$pageData['keywords']]["totalCtr"] = $keywordDetails[$pageData['keywords']]["totalCtr"] + $pageData['ctr'];
                    $keywordDetails[$pageData['keywords']]["totalPosition"] = $keywordDetails[$pageData['keywords']]["totalPosition"] + $pageData['position'];

                    if (isset($keywordDetails[$pageData['keywords']]["sites"][$pageData['site']])) {
                        $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["clicks"] = $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["clicks"] + $pageData['clicks'];
                        $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["impressions"] = $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["impressions"] + $pageData['impressions'];
                        $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["ctr"] = $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["ctr"] + $pageData['ctr'];
                        $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["position"] = $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']]["position"] + $pageData['position'];
                    }
					else {
                        $keywordDetails[$pageData['keywords']]["sites"][$pageData['site']] = $pageData;
                    }

					$keywordDetails[$pageData['keywords']]["completeDetails"][] = $pageData;
                }
				else {

                    $keywordDetails[$pageData['keywords']] = [
                        "totalClicks" => $pageData['clicks'],
                        "totalImpressions" => $pageData['impressions'],
                        "totalCtr" => $pageData['ctr'],
                        "totalPosition" => $pageData['position'],
                        "keywords" => $pageData['keywords'],
                        "sites" => [
                            $pageData['site'] => $pageData
                        ],
						"completeDetails" => [$pageData]
                    ];
                }
            }
        }

        return $keywordDetails;
    }



    public function getSitesListing(Request $request)

    {

        $siteURLs = [];

        $postData = ($request->isMethod('post')) ? $request->input() : [];



        if (

            isset($postData['searchSite']) &&

            !empty($postData['searchSite'])

        ) {

            $sites = ConsoleSitesDataModel::select(["site"])->where("site", "LIKE", '%' . $postData['searchSite'] . '%')->distinct()->get()->toArray();



            if (!empty($sites)) {

                foreach ($sites as $site) {

                    if (isset($site['site']) && !empty($site['site'])) $siteURLs[trim($site['site'])] = $site['site'];
                }
            }
        }



        print json_encode($siteURLs);
    }

	public function googleSearchConsoleOAuth(Request $request){
        $getData = ($request->isMethod('get')) ? $request->input() : [];
        $postData = ($request->isMethod('post')) ? $request->input() : [];

		if(
			isset($postData['userOAuth']) &&
			$postData['userOAuth']
		){

		}

// 		echo "GETDATA:: <pre>";
// 		print_r($getData);
// 		echo "</pre>POSTDATA:: <pre>";
// 		print_r($postData);
// 		echo "</pre>";
// exit;
        $sites = [];
        $consoleSites = ConsoleSiteInfo::all()->toArray();

        foreach($consoleSites as $consoleSite) {
			$sites[] = $consoleSite['siteUrl'];
        }

        $data = [
            "sites" => $sites
        ];


        return Inertia::render('GoogleSearchConsoleOAuth', $data);
	}

    public function getResultByInsertedSiteURL(Request $request)
    {

        $siteURL = "";
        $siteData = $errors = [];

        $siteData[] =  [
            "date" => "1971-01-01",
            "clicks" => 0,
            "impressions" => 0,
            "ctr" => 0,
            "position" => 0
        ];

        $getData = ($request->isMethod('get')) ? $request->input() : [];
        $postData = ($request->isMethod('post')) ? $request->input() : [];
		$countries = CountriesModel::select(["name", "iso_code"])->distinct()->get()->toArray();

        if (
            (
				isset($postData['site']) &&
				!empty($postData['site'])
			) ||
			(
				isset($getData['site']) &&
				!empty($getData['site'])
			)
        ) {
			$request->filterByDays = (isset($request->filterByDays) && !empty($request->filterByDays)) ? $request->filterByDays : "last6Months";
            $siteURL = (isset($getData['site'])) ? $getData['site'] : $postData['site'];
            $siteData = ConsoleSitesDataModel::select(["date", "clicks", "impressions", "ctr", "position"])->where('site', "like", '%' . $siteURL . '%');
			if(!isset($getData['filterByDays'])) $getData['filterByDays'] = $request->filterByDays;
        }
		else {
            $errors[] = 'Please provide site url to search';
        }

        if($request->filterByDays) {
			$dateRange = $this->getStartEndDateByFilterType($request->filterByDays, (isset($request->startDate) ? $request->startDate : ""), (isset($request->endDate) ? $request->endDate : ""));
			$startDate = isset($dateRange[0]) ? $dateRange[0] : "";
			$endDate = isset($dateRange[1]) ? $dateRange[1] : "";

            $where = [
                ['site', '=', ($siteURL ? $siteURL : (isset($getData['siteURL']) ? base64_decode($getData['siteURL']) : ""))],
                ['date', '>=', $startDate],
                ['date', '<=', $endDate],
            ];

			$where = $this->searchFilterAgainstType($where, $getData);
            $siteData = ConsoleSitesDataModel::select(["date", "clicks", "impressions", "ctr", "position"])->where($where);
        }

        if(
			($request->filterByDays) ||
			(isset($postData['site']) &&
            !empty($postData['site'])
        )){
            $siteData = $siteData->get()->toArray();
        }

        $sitesArr = [];
        $dbsties = ConsoleSiteInfo::all()->toArray();
        foreach ($dbsties as $dbsite) {
            array_push($sitesArr, $dbsite['siteUrl']);
        }
        // years
        $years = [];
        for ($i = 0; $i < count($siteData); $i++) {
            array_push($years, $siteData[$i]['date']);
        }
        //for sortinf year array
        sort($years);

        // perday
        $clicks = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $clicks += $siteData[$i]['clicks'];
        }
        // impressions
        $impressions = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $impressions += $siteData[$i]['impressions'];
        }

        // Sumforaverageposition
        $positionavaeragesum = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $positionavaeragesum += $siteData[$i]['position'];
        }
        // Sumforaveragectr
        $Sumforaveragectr = 0;
        for ($i = 0; $i < count($siteData); $i++) {
            $Sumforaveragectr += $siteData[$i]['ctr'];
        }

        return Inertia::render('SearchByURL', [
            "site" => $siteURL,
            "errors" => $errors,
            "sites" => [],
            "years" => $years,
            "siteData" => $siteData,
            "getData" => $getData,
            "countries" => $countries,
            "averagectr" => number_format($Sumforaveragectr, 2),
            "positionaverage" => $positionavaeragesum,
            "clicks" => $clicks,
            "impressions" => $impressions,
            "startDate" => isset($startDate) ? $startDate : '',
            "endDate" => isset($endDate) ? $endDate : '',
        ]);
    }



/**
*
* Exporting Site Data
**/
	public function exportSiteData(Request $request){

    $authUserCreds = ConsoleTokenModel::select("token_data")->get()->toArray();
    $authUserCreds = json_decode( $authUserCreds[0]["token_data"], 1 );

    /*echo "<pre>", print_r(  $authUserCreds ), "</pre>";
     exit;
*/
    /* Getting gToken, SheetID related to user from Database*/
    /*$authUserCreds = ConsoleTokenModel::select("token_data")->where("user_id", auth()->user()->id )->get()->toArray();*/
  //
  //


    $client = new \Google_Client(); // Creating New Instance of Google client
    $client->setApplicationName("SEO STack"); // Custom Application Name
    $client->setScopes(\Google_Service_Sheets::SPREADSHEETS); // Setting Scope to Spreasheet/Workbook
    $client->addScope("https://www.googleapis.com/auth/webmasters");
    $client->setAuthConfig( public_path('/client_credentials.json') ); // Fetching User Credentials from file
    $client->setRedirectUri( $this->googleRedirectURI ); // Setting up Return/call back url. Must be same as added already.
    $client->setAccessType('offline');
    $client->setApprovalPrompt('force');

    /* Checking if toKen file exists on server *
    if (file_exists($this->tokenFile)) {
      $accessToken = json_decode(file_get_contents($this->tokenFile), true);
    } else {

      // Request authorization from the user.
      $authUrl = $client->createAuthUrl();
      header('Location: ' . filter_var($authUrl, FILTER_SANITIZE_URL));

      if (isset($_REQUEST['code'])) {
        $authCode = $_REQUEST['code'];
        // Exchange authorization code for an access token.
        $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
        header('Location: ' . filter_var($this->googleRedirectURI, FILTER_SANITIZE_URL));

        if(!file_exists(dirname($this->tokenFile))) {
          mkdir(dirname($this->tokenFile), 0700, true);
        }

        file_put_contents($this->tokenFile, json_encode($accessToken));

        } else {
          exit('No code found');
        }
    }*/

  //  $authUserCreds["accessToken"] = $accessToken;

  /*  echo "<pre>", print_r(  $accessToken ), "</pre>";
    exit;*/

    $accessToken = $authUserCreds;
    $client->setAccessToken($accessToken);

    if ($client->isAccessTokenExpired()) {
      $refreshTokenSaved = $client->getRefreshToken();
      $client->fetchAccessTokenWithRefreshToken($refreshTokenSaved);
    }

    $service = new \Google_Service_Sheets($client);

    if (file_exists($this->sheetFile)) {
      $sheetData = json_decode(file_get_contents($this->sheetFile), true);
      /*$sheetDatas['spreadSheetId'] = $sheetData;
      echo "<pre>", print_r( json_encode( $sheetDatas ) ), "</pre>"; exit;*/
      $spreadSheetId = $sheetData["spreadSheetId"];
      //if( !isset( $authUserCreds["spreadSheetId"] ) || !$authUserCreds["spreadSheetId"] || $authUserCreds["spreadSheetId"] == 0 ) {
    } else {
      $requestBody = new Google_Service_Sheets_Spreadsheet([
              'properties' => [
                  'title' => "My Seo Data",
              ]
          ]);
      $response = $service->spreadsheets->create($requestBody);
      $spreadSheetId['spreadSheetId'] = $response->getSpreadsheetId();

      if(!file_exists(dirname($this->sheetFile))) {
        mkdir(dirname($this->sheetFile), 0700, true);
      }

      file_put_contents($this->sheetFile, json_encode($spreadSheetId));
    }


  /*  echo "<pre>", print_r( $authUserCreds ), "</pre>";
    exit;*/


    // Getting SpreadSheet
    $spreadsheet = $service->spreadsheets->get($spreadSheetId);
    $postData = ($request->isMethod('post')) ? $request->input() : [];

		if( isset($postData['site']) && !empty($postData['site'])	){
			$postData['filterByDays'] = (isset($postData['filterByDays']) && !empty($postData['filterByDays'])) ? $postData['filterByDays'] : "last6Months";
			$dateRange = $this->getStartEndDateByFilterType($postData['filterByDays'], (isset($postData["startDate"]) ? $postData["startDate"] : ""), (isset($postData["endDate"]) ? $postData["endDate"] : ""));
			$startDate = isset($dateRange[0]) ? $dateRange[0] : "";
			$endDate = isset($dateRange[1]) ? $dateRange[1] : "";

			$where = [
				['site', '=', $postData['site']],
				['date', '>=', $startDate],
				['date', '<=', $endDate],
			];

			$where = $this->searchFilterAgainstType($where, $postData);

			$siteData = ConsoleSitesDataModel::select(["site", "date", "clicks", "impressions", "ctr", "position", "keywords"])->where($where)->get()->toArray();
			$fileName = stripslashes($postData['site']);
			$fileName = str_replace(["https://", "http://", "/"], "", $fileName)."-".date("H-i-s").".csv";

			$headers = array(
				"Content-type" => "text/csv",
				"Content-Disposition" => "attachment; filename=$fileName",
				"Pragma" => "no-cache",
				"Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
				"Expires" => "0"
			);

			$columns = ['Site', 'Date', 'Clicks', 'Impressions', 'Ctr', 'Position', 'Keywords'];

      $siteDataforGoogle =[$columns];
      foreach( $siteData as $data) {
        $siteDataforGoogle[] = array_values( $data );
      }

      $sheetStartDate = $siteDataforGoogle[1][1];
      $sheetEndDate = $siteDataforGoogle[ count( $siteDataforGoogle ) - 1 ][1];

      $sheetName = str_replace(["https://", "http://", "www.", "/", ":"], "", $siteData[0]["site"] ) ;
      $sheetName .= " (". $sheetStartDate ." upto ". $sheetEndDate .")";

      $sheetInfo = $service->spreadsheets->get($spreadSheetId);
      $allSheetInfo = $sheetInfo['sheets'];
      $allSheets = array_column($allSheetInfo, 'properties');
      $sheetExists = 0;

      foreach( $allSheets as $sheet ) {
        if( $sheet->title == $sheetName ) {
          $sheetExists = true;
        }
      }

      if( !$sheetExists ) {
        //Create New Sheet
        $body = new \Google_Service_Sheets_BatchUpdateSpreadsheetRequest([
              'requests' => [
                            'addSheet' => [
                                          'properties' => [ 'title' => $sheetName ]
                                        ]
                            ]
            ]);

        $result = $service->spreadsheets->batchUpdate($spreadSheetId, $body);
        $sheetID = $result->replies[0]->addSheet->properties->sheetId;

      } else {
        /* Since Sheet Exists with same name and date window.
        Therefor need to clear previous data */

        $range = $sheetName . '!A1:Z';
        $sheetCleanRequest = new \Google_Service_Sheets_ClearValuesRequest();
        $response = $service->spreadsheets_values->clear($spreadSheetId, $range, $sheetCleanRequest);
      }

      $valueRange = new \Google_Service_Sheets_ValueRange();
      $valueRange->setValues($siteDataforGoogle);
      $options = ['valueInputOption' => 'USER_ENTERED'];
      $service->spreadsheets_values->append($spreadSheetId, $sheetName, $valueRange, $options);

			$callback = function() use($siteData, $columns) {
				$file = fopen('php://output', 'w');
				fputcsv($file, $columns);

				foreach ($siteData as $data) {
					fputcsv($file, [$data['site'], $data['date'], $data['clicks'], $data['impressions'], $data['ctr'], $data['position'], $data['keywords']]);
				}

				fclose($file);
			};





    /*  $userCredsUpdate = UserApiCredentials::where("user_id", auth()->user()->id )->firstOrFail();
        $userCredsUpdate->credentials = json_encode( $authUserCreds );
        $userCredsUpdate->updated_at = date('Y-m-d h:i:s');
      $userCredsUpdate->update();*/

			return response()->stream($callback, 200, $headers);

		}
	}

}
