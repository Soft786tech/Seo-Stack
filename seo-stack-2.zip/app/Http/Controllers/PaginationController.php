<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PaginationController extends Controller
{
	public function showPaginationsFunc($totalCount, $limitTo, $pageURL=[], $isAdmin=0, $isNextPrevious=0, $isQuery=0){
		$paginationHtml = '';
        
		if($totalCount > $limitTo && $limitTo > 0){
			$currentPageURL = $this->currentPageURL();

			
			
            
			$pageURL = ($pageURL) ? $pageURL : [$currentPageURL, "list_page"];
			
			
			$totalPages = $totalCount/$limitTo;
			$totalPages = ceil($totalPages);
		
			$adminClass = ($isAdmin) ? "pagination" : "";
			$activeClass = ($isAdmin) ? "active" : "";
			$nextPreviousClass = ($isAdmin) ? "" : "next-previous-class";
			$adjacents = 2;
			$querySap = (isset($pageURL[3]) && $pageURL[3] == 1) ? '&' : '?';
			
			$secondLast = $totalPages - 1;			

			if($totalPages > 0){				
				$checkPagination = explode("/", $currentPageURL);
				
				$pageNumber = end($checkPagination);	
				$checkPagination = prev($checkPagination);			
				
				$nextPage = (isset($_GET[$pageURL[1]])) ? $_GET[$pageURL[1]] + 1 : 2;
				$nextPage = (is_numeric($pageNumber)) ? $pageNumber + 1 : $nextPage;
				$nextPage = ($nextPage >= $totalPages) ?  $totalPages : $nextPage;				
				$prevPage = (isset($_GET[$pageURL[1]])) ? $_GET[$pageURL[1]] - 1 : 0;
				$prevPage = (is_numeric($pageNumber)) ? $pageNumber - 1 : $prevPage;
				$prevPage = ($prevPage > $totalPages) ?  $totalPages : $prevPage;
				$adjacents = ((isset($_GET[$pageURL[1]]) && $_GET[$pageURL[1]] == 6) || (is_numeric($pageNumber) && $pageNumber == 6)) ? 1 : $adjacents;
				$paginationHtml .= '<div class="card-footer d-sm-flex justify-content-between align-items-center">';	
					$paginationHtml .= '<nav>';	
						if(isset($pageURL[2]) && $pageURL[2]){								
							$paginationHtml .= '<li class="page-item page-indicator">';
								$paginationHtml .= '<a class="page-first page-link" pageNumber="'.$prevPage.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $nextPage, $isQuery).'">«</a>';
							$paginationHtml .= '</li>';
						}
						
						$paginationHtml .= '<ul class="justify-content-center w-space-no pagination pagination-gutter m-0 '.$adminClass.'">';										
							$paginationHtml .= ($isAdmin || $isNextPrevious) ? '<li class="page-item"><a class="'.$nextPreviousClass.' page-first page-link" pageNumber="'.$prevPage.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $prevPage, $isQuery).'">«</a></li>' : '';
							if($totalPages <= 10){
								$paginationHtml .= $this->randerPagination($totalPages, $activeClass, $pageURL, $querySap, $isQuery);							
							}
							else if($totalPages > 10){
								if(
									(
										isset($_GET[$pageURL[1]]) && 
										$_GET[$pageURL[1]] <= 5
									) ||
									(
										is_numeric($pageNumber) &&
										$pageNumber <= 5									
									)	
								){
									$paginationHtml .= $this->randerPagination(8, $activeClass, $pageURL, $querySap, $isQuery);
									$paginationHtml .= $this->postPaginationRander($activeClass, $secondLast, $totalPages, $pageURL, $querySap, $isQuery);												
								}
								else if(
									(
										isset($_GET[$pageURL[1]]) && 
										$_GET[$pageURL[1]] > 5 && 
										$_GET[$pageURL[1]] < $totalPages - 5
									) ||									
									(
										is_numeric($pageNumber) && 
										$pageNumber > 5 && 
										$pageNumber < $totalPages - 5
									)
								){
									$pageAdjacents = isset($_GET[$pageURL[1]]) ? $_GET[$pageURL[1]] : $pageNumber;
									$paginationHtml .= $this->prePaginationRander($activeClass, $pageURL, $querySap, $isQuery);	
									$paginationHtml .= $this->randerPagination($totalPages, $activeClass, $pageURL, $querySap, $isQuery, ($pageAdjacents - $adjacents), ($pageAdjacents + $adjacents));
									$paginationHtml .= $this->postPaginationRander($activeClass, $secondLast, $totalPages, $pageURL, $querySap, $isQuery);	
								}
								else{
									$paginationHtml .= $this->prePaginationRander($activeClass, $pageURL, $querySap, $isQuery);	
									$paginationHtml .= $this->randerPagination($totalPages, $activeClass, $pageURL, $querySap, $isQuery, ($totalPages - 6));
								}
							}
							$paginationHtml .= ($isAdmin || $isNextPrevious) ? '<li class="page-item page-indicator"><a class="'.$nextPreviousClass.' page-next page-link" pageNumber="'.$nextPage.'"  href="'.$this->getPaginationPageURL($pageURL, $querySap, $nextPage, $isQuery).'">»</a></li>' : '';
						$paginationHtml .= '</ul>';	
					$paginationHtml .= '</nav>';
				$paginationHtml .= '</div>';	
			}
			
		}
       
		
		return $paginationHtml;
	}
	
	private function getPaginationPageURL($pageURL, $querySap, $page, $isQuery, $isPrev=0){
	    
		$paginationURL = ($isQuery) ? $pageURL[0]."/page/".$page : $pageURL[0].$querySap.http_build_query([$pageURL[1] => $page]);
		
		return ($page <= 0) ? $pageURL[0] : $paginationURL;
		
	}
	
	private function prePaginationRander($activeClass, $pageURL, $querySap, $isQuery){
		$currentPageURL = $this->currentPageURL();
		$checkPagination = explode("/", $currentPageURL);
		$pageNumber = end($checkPagination);		

		$paginationHtml = '';
		
		for($counter=1; $counter<6; $counter++){			
			$paginationHtml .= '<li class="page-item '.($pageNumber == $counter ? $activeClass : "").'"><a class="page-2 page-link" pageNumber="'.$counter.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $counter, $isQuery).'">'.$counter.'</a></li>';	
		}
		
		$paginationHtml .= '<li class="'.$activeClass.' page-item page-indicator"><a class="page-numbers '.$activeClass.'">...</a></li>';		
		
		return $paginationHtml;
	}	
	
	private function postPaginationRander($activeClass, $secondLast, $totalPages, $pageURL, $querySap, $isQuery){		
		$paginationHtml = '';
		$paginationHtml .= '<li class="page-item '.$activeClass.'"><a class="page-numbers page-link">...</a></li>';
		$paginationHtml .= '<li class="page-item"><a class="page-numbers page-link" pageNumber="'.$secondLast.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $secondLast, $isQuery).'">'.$secondLast.'</a></li>';
		$paginationHtml .= '<li class="page-item"><a class="page-numbers page-link" pageNumber="'.$totalPages.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $totalPages, $isQuery).'">'.$totalPages.'</a></li>';		
		
		return $paginationHtml;
	}
	
	private function randerPagination($totalPages, $activeClass, $pageURL, $querySap, $isQuery, $startCounter=0, $endCounter=0){
		$paginationHtml = "";

		if($totalPages > 0){
			$endCounter = ($endCounter == 0) ? $totalPages : $endCounter;
			$checkPagination = explode("/", $this->currentPageURL());
			$pageNumber = end($checkPagination);
			$checkPagination = prev($checkPagination);
			
			for($counter=$startCounter; $counter<$endCounter; $counter++){
				$number = $counter + 1;
				
				if(
					(
						isset($_GET[$pageURL[1]]) && 
						$_GET[$pageURL[1]] > 0
					) || 
					(
						isset($_POST['next_list_page']) && 
						$_POST['next_list_page'] > 0
					) || 
					(
						is_numeric($pageNumber)
					)
				){
					if(
						(
							isset($_GET[$pageURL[1]]) && 
							$number == $_GET[$pageURL[1]]
						) || 
						(
							isset($_POST['next_list_page']) && 
							$number == $_POST['next_list_page']
						) || 
						(
							is_numeric($pageNumber) && 
							$number == $pageNumber
						)
					){
						$paginationHtml .= '<li class="page-item '.$activeClass.'"><a class="page-numbers page-link">'.$number.'</a></li>';	
					}
					else if($counter == 0){
						$paginationHtml .= '<li class="page-item"><a class="page-numbers page-link" pageNumber="'.$number.'" href="'.$pageURL[0].'">'.$number.'</a></li>';
					}
					else{												
						$paginationHtml .= '<li class="page-item"><a class="page-numbers page-link" pageNumber="'.$number.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $number, $isQuery).'">'.($counter+1).'</a></li>';
					}
				}
				else{	
					if($counter == 1){
						$paginationHtml .= '<li  class="page-item"><a class="page-numbers page-link" pageNumber="'.$number.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $number, $isQuery).'">'.$number.'</a></li>';
					}
					else if($counter > 1){
						$paginationHtml .= '<li  class="page-item"><a class="page-numbers page-link" pageNumber="'.$number.'" href="'.$this->getPaginationPageURL($pageURL, $querySap, $number, $isQuery).'">'.$number.'</a></li>';
					}
					else{						
						$paginationHtml .= '<li  class="page-item '.$activeClass.'"><a class="page-link">'.$number.'</a></li>';	
					}
				}	
			}
		}			
		
		return $paginationHtml;
	}

	public function currentPageURL($urlType=""){
		$pageURL = 'http';
		$removePorts = [80, 443];
		if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
		$pageURL .= "://";
		if (!in_array($_SERVER["SERVER_PORT"], $removePorts)) {
			$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
		} 
		else{
			if($urlType == "feed"){
				$requestURI = (strpos($_SERVER["REQUEST_URI"] , "?") !== false) ? str_replace("?", "/feed?", $_SERVER["REQUEST_URI"]) : $_SERVER["REQUEST_URI"]."/feed";
			}
			else{
				$requestURI = $_SERVER["REQUEST_URI"];
			}
			$pageURL .= $_SERVER["SERVER_NAME"].$requestURI;
		}
		return $pageURL;
	}		
}